import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voucher-form',
  templateUrl: './voucher-form.component.html',
  styleUrls: ['./voucher-form.component.css']
})
export class VoucherFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
