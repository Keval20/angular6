import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicePackageFormComponent } from './service-package-form.component';

describe('ServicePackageFormComponent', () => {
  let component: ServicePackageFormComponent;
  let fixture: ComponentFixture<ServicePackageFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServicePackageFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicePackageFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
