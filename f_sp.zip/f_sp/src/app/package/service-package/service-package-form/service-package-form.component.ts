import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-package-form',
  templateUrl: './service-package-form.component.html',
  styleUrls: ['./service-package-form.component.css']
})
export class ServicePackageFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
