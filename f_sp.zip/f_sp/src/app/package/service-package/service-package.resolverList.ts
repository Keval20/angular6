import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable, of } from 'rxjs';

import { catchError, map, tap, delay } from 'rxjs/operators';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { PackageService } from '../package.service';
@Injectable()

// newly added by vighnesh
export class ServicePackageResolverList implements Resolve<any> {
    user: string;
    formData: FormData = new FormData();
    constructor(
        // private service: PackageService
    ) { }
    resolve() {
        //  return this.service.list()
    }
}