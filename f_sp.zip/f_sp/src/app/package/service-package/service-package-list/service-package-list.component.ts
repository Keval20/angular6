import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { ServicePackageListDataSource } from './service-package-list-datasource';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { CommonService } from '../../../shared/common.service';
import { DialogOverviewExampleDialog } from '../../../shared/dialog/dialog';



@Component({
  selector: 'package/service-package-list',
  templateUrl: './service-package-list.component.html',
  styleUrls: ['./service-package-list.component.css']
})

export class ServicePackageListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public loading = false;
  dataSource: any;
  responseData: any;
  formData: FormData = new FormData();
  action: string;
  user: any;
  dataq: any;
  dataonce: any[];
  filteredData: any[];
  filteredTotal: number;

 
  

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['_id', 'name', 'action'];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private service: CommonService
  ) { }

  
 

  ngOnInit() {
    this.responseData = this.route.snapshot.data.list;
    this.dataSource = new ServicePackageListDataSource(this.paginator, this.sort, this.responseData);
  }

  fetch() {
    this.user = localStorage.getItem('currentUser');
    var obj = JSON.parse(this.user);
    this.formData.append('access_token', obj.access_token);
    this.formData.append('user_id', obj.id)
    this.service.list('user/list').subscribe(
      data => { this.dataq = data; },
      err => { console.error(err), this.loading = false; },
      () => {
        this.dataonce = this.dataq.data;
        this.filteredData = this.dataq.data;
        console.log(' this.filteredData::', this.filteredData)
        this.filteredTotal = this.dataonce.length;
        this.loading = false;
        //  this.filter()
      }
    );

  }

  delete(row): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '250px',
      data: { message: 'Are you sure you want to delete this record ? ' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {
        this.user = localStorage.getItem('currentUser');
        var obj = JSON.parse(this.user);
        this.formData.append('access_token', obj.access_token); this.formData.append('user_id', obj.id)
        this.formData.append('id', row.id)
        this.service.delete('customer/delete', this.formData).subscribe(
          data => { this.dataq = data; },
          err => console.error(err),
          () => { this.fetch() }
        )
      }
      console.log('The dialog was closed', result);
    });
  }


  changeStatus(row): void {
    this.action = (row.status == 'Active') ? 'Pending' : "Active";
    let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '250px',

      data: { message: 'Are you sure you want to ' + this.action + ' this record ? ' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {
        this.user = localStorage.getItem('currentUser');
        var obj = JSON.parse(this.user);
        this.formData.append('access_token', obj.access_token); this.formData.append('user_id', obj.id)
        this.formData.append('id', row.id)
        this.service.status('customer/status', this.formData).subscribe(
          data => { this.dataq = data; },
          err => console.error(err),
          () => { this.fetch() }
        )
      }
      console.log('The dialog was closed', result);
    });
  }
}
