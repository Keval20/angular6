import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { observable, of } from 'rxjs';
import { CommonService } from '../shared/common.service';
@Injectable({
  providedIn: 'root'
})
export class PackageService {

  response
  constructor(
    private http: HttpClient,
    private common: CommonService
  ) { }

  list() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        "x-auth": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1YjFmYzJmYmM2MTI5ZjAzYmM3ODYzZTAiLCJhY2Nlc3MiOiJhdXRoIiwiaWF0IjoxNTI5NDE4NDk1fQ._ITW-yA6QFNBbaweNgbwosuEmzszm0MPGFzKaDYccwc"
      })
    };
    return this.http.get(this.common.apiendpoint + 'service-provider/service-type', httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          if (this.response.code == 200) {
          } else {
            // this.common.error(this.response.message, '')
          }
        }),
        catchError(this.common.handleError)
      );

  }
  
}
