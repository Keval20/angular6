import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VoucherListComponent } from './voucher/voucher-list/voucher-list.component';
import { VoucherFormComponent } from './voucher/voucher-form/voucher-form.component';
import { ServicePackageFormComponent } from './service-package/service-package-form/service-package-form.component';
import { ServicePackageListComponent } from './service-package/service-package-list/service-package-list.component';
import { ServicePackageResolverList } from './service-package/service-package.resolverList';
import { ServicePackageResolverDetails } from './service-package/service-package.resolverListDetails';
import { VoucherResolverList } from './voucher/voucher.resolverList';
import { VoucherResolverDetails } from './voucher/voucher.resolverDetails';


const routes: Routes = [
  {
    path: 'voucher',
    component: VoucherListComponent,
    resolve: {
      list: VoucherResolverList,
    }
  },
  {
    path: 'voucher/add',
    component: VoucherFormComponent,
  },
  {
    path: 'voucher/edit/:id',
    component: VoucherFormComponent,
    resolve: {
      list: VoucherResolverDetails,
    }
  },
  {
    path: 'service-package',
    component: ServicePackageListComponent,
    resolve: {
      list: ServicePackageResolverList,
    }
  },
  {
    path: 'service-package/add',
    component: ServicePackageFormComponent,
  },
  {
    path: 'service-package/edit/:id',
    component: ServicePackageFormComponent,
    resolve: {
      details: ServicePackageResolverDetails
    }
  }




];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    ServicePackageResolverList,
    ServicePackageResolverDetails,
    VoucherResolverList,
    VoucherResolverDetails
  ]
})
export class PackageRoutingModule { }
