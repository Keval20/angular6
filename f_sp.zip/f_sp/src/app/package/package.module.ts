import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/material/material.module';
import { PackageRoutingModule } from './package-routing.module';

import { VoucherListComponent } from './voucher/voucher-list/voucher-list.component';
import { VoucherFormComponent } from './voucher/voucher-form/voucher-form.component';
import { ServicePackageFormComponent } from './service-package/service-package-form/service-package-form.component';
import { ServicePackageListComponent } from './service-package/service-package-list/service-package-list.component';



@NgModule({
  imports: [
    CommonModule,
    PackageRoutingModule,
    MaterialModule
  ],
  declarations: [
    VoucherListComponent,
    VoucherFormComponent,
    ServicePackageFormComponent,
    ServicePackageListComponent
  ]
})
export class PackageModule { }
