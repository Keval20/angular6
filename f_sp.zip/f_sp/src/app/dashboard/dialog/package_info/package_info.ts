import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

// import { CommonService } from '../../../shared/common.service';

@Component({
    selector: 'package_infoDialog',
    templateUrl: 'package_info.html',
    styleUrls: ['./package_info.css']
})
export class packageInfoDialog {
    userFormData = {};
    field_yes = true
    field_no = false
    canEdit = false
    cancelWithOutEdit;
    constructor(
        public dialogRef: MatDialogRef<packageInfoDialog>,
        // private service: CommonService,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

    edit() {
        this.canEdit = true;
    }

}