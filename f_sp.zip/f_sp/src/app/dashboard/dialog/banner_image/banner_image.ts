import { Component, HostBinding, Inject, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DragScrollComponent } from 'ngx-drag-scroll';
import { CommonService } from '../../../shared/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { TranslateService } from '../../../translate.service';


@Component({
    selector: 'banner-image-dialog',
    templateUrl: 'banner_image.html',
    styleUrls: ['./banner_image.css'],

})
export class bannerImageDialog {

    showFileUpload: boolean;
    canEdit = false;
    dialgContactData = {};
    id;
    image = [];
    fileToUpload: File[];
    language: String;
    cancelWithOutEdit;
    
    constructor(
        public dialogRef: MatDialogRef<bannerImageDialog>,
        public services: CommonService,
        private router: Router,
        private route: ActivatedRoute,
        private translateService: TranslateService,

        @Inject(MAT_DIALOG_DATA) public data: any) {
        console.log('bannerImageDialog', this.data)
        if (Array.isArray(this.data.data.bannerImages)) {
            if (this.data.data.bannerImages.length <= 5) {
                this.showFileUpload = true;
            } else {
                this.showFileUpload = false;
            }

        }
    }

    cancel(): void {
        this.canEdit = false;
    }

    ngOnInit() {
        this.language = this.services.getlanguage();
        // console.log("in info::", this.language);
    }

    @ViewChild('nav', { read: DragScrollComponent }) ds: DragScrollComponent;

    @ViewChild('myInput')
    myInputVariable: ElementRef;

    moveLeft() {
        this.ds.moveLeft();
    }

    moveRight() {
        this.ds.moveRight();
    }

    //** Delete uploaded function */
    deleteImg(index) {
        // console.log("imageIndex", index)

        if (!localStorage.getItem('_id')) {
            this.router.navigate(['auth/login']);
        }
        this.id = localStorage.getItem('_id')
        var data = {
            "serviceProviderId": this.data.myspid,
            "imageId": index._id,
            "imageUrl": index.imageUrl,
            "lang": localStorage.getItem('lang')

        }
        // console.log("id", JSON.stringify(data))
        console.log("data123::", data.lang)
        var url = "admin/service-provider/image/delete"
        this.services.add(url, data).subscribe(
            data => {
                if (data) {
                    this.services.success(data.message, 'Okay')
                    this.router.navigate(['main/dashboard'])
                    this.dialogRef.close();
                }
            }

        )

    }

    //** Resete image function */
    Reset(img, index) {
        console.log("img", img)
        // this.image = []
        this.image.splice(index, 1);
        console.log(this.myInputVariable.nativeElement.files);
        this.myInputVariable.nativeElement.value = "";
        console.log(this.myInputVariable.nativeElement.files);
    }

    //** Onselect image privew function */

    onSelectFile(event, images) {
        let toalImages = images.length + this.data.data.bannerImages.length + event.target.files.length;
        console.log('toalImages::', toalImages);
        if (toalImages <= 5) {
            this.fileToUpload = event.target.files;
            if (event.target.files && event.target.files[0]) {
                var filesAmount = event.target.files.length;
                for (let i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();
                    reader.onload = (event: any) => {
                        // console.log(event.target.result);
                        this.image.push(event.target.result);
                    }
                    reader.readAsDataURL(event.target.files[i]);
                }
            }
        } else {
            console.log('elsetoalImages', toalImages);
            this.myInputVariable.nativeElement.value = "";
            if (localStorage.getItem("lang") == "ar") {
                this.services.error('لا يمكنك أضافه أكثر من خمس صور', '')
            } else {
                this.services.error('You cannot add more than five images', 'Okay')
            }

        }
    }
    //** Banner Image Save function */
    save(data) {
        // console.log("form123 data.length::", data.length)
        if (data.status == "VALID") {

            if (!localStorage.getItem('_id')) {
                this.router.navigate(['auth/login']);
            }
            var formData: FormData = new FormData();
            Array.from(this.fileToUpload).forEach(f =>
                formData.append('bannerImages', f),
                formData.append('lang', localStorage.getItem('lang'))
            )
            var url = 'admin/service-provider/image/add/' + this.data.myspid
            this.services.addFormData(url, formData).subscribe(
                data => {
                    if (data) {
                        this.services.success(data.message, "Okay")
                        this.router.navigate(['main/dashboard'])
                        this.dialogRef.close('yes');
                    }
                },

            )
        }
    }


    // onSelectFile(event, image) {
    //     if (image.length < 5) {

    //     } else {
    //         this.services.error('You can not add more than five images', 'Okay')
    //     }

    //     console.log('image', image.length)
    //     this.fileToUpload = event.target.files
    //     if (event.target.files && event.target.files[0]) {
    //         var filesAmount = event.target.files.length;
    //         for (let i = 0; i < filesAmount; i++) {
    //             var reader = new FileReader();
    //             reader.onload = (event: any) => {
    //                 this.image.push(event.target.result);
    //             }

    //             reader.readAsDataURL(event.target.files[i]);
    //         }
    //     }
    // }
}



