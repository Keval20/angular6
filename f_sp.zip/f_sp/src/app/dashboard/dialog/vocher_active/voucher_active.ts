import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';

import { CommonService } from '../../../shared/common.service';

@Component({
    selector: 'voucher_activedialog',
    templateUrl: 'voucher_active.html',
    styleUrls: ['./voucher_active.css']
})
export class voucherActiveDialog {
    field_yes = true
    field_no = false
    canEdit = false
    dialgInfoData = {}
    id;
    dataq;
    language: String;
    cancelWithOutEdit;
    constructor(
        public dialogRef: MatDialogRef<voucherActiveDialog>,
        private service: CommonService,
        private route: ActivatedRoute,
        private router: Router,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) {

        console.log('info diaglog', this.data)

    }

    ngOnInit() {
        this.language = this.service.getlanguage();
    }


    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

    edit() {
        this.canEdit = true;

    }
    cancel(): void {
        this.canEdit = false;
        this.dialgInfoData = null
    }

    //** Voucher Active function */
    activateVoucher(form) {
        if (!localStorage.getItem('_id')) {
            this.router.navigate(['auth/login']);
        }
        this.dialgInfoData = {
            voucher: this.data.data['_id'],
            _serviceProvider: this.data.data['_serviceProvider'],
            activationPin: this.data.data['activationPin'],

        }
        console.log("voucherData::", this.dialgInfoData);
        var url = 'user/avail-voucher'
        this.service.add(url, this.dialgInfoData).subscribe(
            // this.service.update('review-and-rating/comment/' + this.userId , this.userFormData).subscribe(
            data => {
                if (data) {
                    this.service.success(data.message, "Okay")
                }
            }
            // data => { this.dataq = data },
            // err => { console.error('error found', err); this.router.navigate(['error', '404']); },
            // () => {
            //     this.dialogRef.close(this.dialgInfoData);
            //     this.router.navigate(['main/voucher']);
            // }

        )

    }


}