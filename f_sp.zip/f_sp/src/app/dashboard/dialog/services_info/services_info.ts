import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from '../../../shared/common.service';


@Component({
    selector: 'services_infoDialog',
    templateUrl: 'services_info.html',
    styleUrls: ['./services_info.css']
})
export class servicesInfoDialog {
    language: String;
    canEdit = false;
    dialgContactData = {};
    cancelWithOutEdit;
    constructor(
        public service: CommonService,
        public dialogRef: MatDialogRef<servicesInfoDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {
        console.log('contact diaglog', this.data)
    }


    ngOnInit() {
        this.language = this.service.getlanguage();
        console.log("in info::", this.language);
    }



    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

    edit() {
        this.canEdit = true;

    }
    cancel(): void {
        this.canEdit = false;
    }


}