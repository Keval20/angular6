import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { CommonService } from '../../../shared/common.service';
import { TranslateService } from '../../../translate.service';

@Component({
    selector: 'info-dialog',
    templateUrl: 'info.html',
    styleUrls: ['./info.css']
})
export class infoDialog {
    field_yes = true
    field_no = false
    canEdit = false
    dialgInfoData = {}
    dataq;
    responseData;
    parkingaccess: any = "false";
    language: String;
    cancelWithOutEdit;
    constructor(
        public dialogRef: MatDialogRef<infoDialog>,
        private service: CommonService,
        private translateService: TranslateService,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) {
        console.log('data.infoData:: ', data.infoData)

        // if (this.data) {
        //     this.parkigAccessclicked();
        // }
    }


    ngOnInit() {
        this.language = this.service.getlanguage();
        // console.log("in info::", this.language);
    }

    parkigAccessclicked() {
        // console.log("parkigAccessclicked function")
        this.parkingaccess = !this.parkingaccess;
    }

    // ngOnInit() {
    //     this.parkingaccess = !this.parkingaccess;
    // }


    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

    edit() {
        this.canEdit = true;
    }

    cancel(): void {
        this.canEdit = false;
        this.dialgInfoData = null
        // this.fetch();
    }


    // fetch() {
    //     console.log("this is fetch() function");
    //     this.service.myPlan('service-provider/myplanq1').subscribe(

    //         data => {
    //             if (data) {
    //                 this.responseData = data;
    //                 this.canEdit = false;
    //                 // this.dialgInfoData = '';
    //                 console.log("responseData::", this.responseData)
    //             }
    //         },

    //     )

    // }

    save(): void {
        let dialgInfoData = {
            parkingAccess: this.data.infoData['parkingAccess'],
            parkingMinutes: this.data.infoData['parkingMinutes'],
            wheelChairAccess: this.data.infoData['wheelChairAccess'],
            wifiAcces: this.data.infoData['wifiAcces'],
            openingTime: this.data.infoData['openingTime'],
            closingTime: this.data.infoData['closingTime'],
        }
        this.dialogRef.close(dialgInfoData);
    }

    onChangeParkingAccess(enable: boolean) {
        // console.log('enable ', enable)
        if (enable) {
            this.data.infoData['parkingAccess'] = this.field_yes
        } else {
            this.data.infoData['parkingAccess'] = this.field_no
        }
    }

    onChangewheelChairAccess(enable: boolean) {
        // console.log('enable ', enable)
        if (enable) {
            this.data.infoData['wheelChairAccess'] = this.field_yes
        } else {
            this.data.infoData['wheelChairAccess'] = this.field_no
        }
    }

    onChangewifiAcces(enable: boolean) {
        // console.log('enable ', enable)
        if (enable) {
            this.data.infoData['wifiAcces'] = this.field_yes
        } else {
            this.data.infoData['wifiAcces'] = this.field_no
        }
    }

    /*Validation Number */
    only_number(event) {
        var k;
        k = event.charCode;  //         k = event.keyCode;  (Both can be used)
        // console.log('key:' + k + "return : " + (k >= 48 && k <= 57))
        return ((k >= 48 && k <= 57));
    }


}