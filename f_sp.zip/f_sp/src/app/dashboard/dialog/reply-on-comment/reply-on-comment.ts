import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';

import { CommonService } from '../../../shared/common.service';

@Component({
    selector: 'replyOnCommentDialog',
    templateUrl: 'reply-on-comment.html',
    styleUrls: ['./reply-on-comment.css']
})
export class replyOnCommentDialog {

    canEdit = true;
    dialogInfoData = {}
    dataq;
    userFormData = {}
    toastMessage: String;
    userId;
    reviews = {};
    id;
    cancelWithOutEdit;

    constructor(
        public dialogRef: MatDialogRef<replyOnCommentDialog>,
        private service: CommonService,
        private router: Router,
        private route: ActivatedRoute,
        @Inject(MAT_DIALOG_DATA) public data: any) {
        console.log('replay on comment diaglog', this.data)

    }

    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

    edit() {
        this.canEdit = true;

    }
    cancel(): void {
        this.canEdit = false;
    }

    submitComment(form): void {
        if (form.status == "VALID") {
            var reviewid = this.data.review._id

            if (!localStorage.getItem('_id')) {
                this.router.navigate(['auth/login']);
            }
            this.id = localStorage.getItem('_id')

            var commentData = {
                "_user": this.id,
                "ownerReply": form.value.ownerReply,
                lang: localStorage.getItem("lang")
            }
            console.log("commentData::", commentData);

            var url = 'review-and-rating/owner-reply/' + reviewid
            this.service.update(url, commentData).subscribe(
                data => {
                    if (data) {
                        this.service.success(data.message, 'Okay');
                        this.router.navigate(['main/dashboard']);
                        this.dialogRef.close();
                    }
                },
            )
        }
    }



}