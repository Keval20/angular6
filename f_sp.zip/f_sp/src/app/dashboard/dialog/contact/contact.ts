import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TranslateService } from '../../../translate.service';


@Component({
    selector: 'contact-dialog',
    templateUrl: 'contact.html',
    styleUrls: ['./contact.css']
})
export class contactDialog {

    canEdit = false;
    dialgContactData = {};
    cancelWithOutEdit;
    constructor(
        public dialogRef: MatDialogRef<contactDialog>,
        private translateService: TranslateService,
        @Inject(MAT_DIALOG_DATA) public data: any) {
        console.log('contact diaglog', this.data)
    }

    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

    edit() {
        this.canEdit = true;

    }
    cancel(): void {
        this.canEdit = false;
        this.dialgContactData = null
    }

    save(): void {
        let dialgContactData = {
            phoneNumber: this.data.contactUsData['contactInformation']['phoneNumber'],
            email: this.data.contactUsData['contactInformation']['email'],
            website: this.data.contactUsData['contactInformation']['website'],
            facebook: this.data.contactUsData['contactInformation']['facebook'],
            twitter: this.data.contactUsData['contactInformation']['twitter'],
            instagram: this.data.contactUsData['contactInformation']['instagram'],
        }
        this.dialogRef.close(dialgContactData);
    }


    // save(): void {
    //     this.dialgContactData = {
    //         phoneNumber: this.data.contactUsData['serviceProviderDocument']['contactInformation']['phoneNumber'],
    //         email: this.data.contactUsData['serviceProviderDocument']['contactInformation']['email'],
    //         website: this.data.contactUsData['serviceProviderDocument']['contactInformation']['website'],
    //         facebook: this.data.contactUsData['serviceProviderDocument']['contactInformation']['facebook'],
    //         twitter: this.data.contactUsData['serviceProviderDocument']['contactInformation']['twitter'],
    //         instagram: this.data.contactUsData['serviceProviderDocument']['contactInformation']['instagram'],
    //     }
    //     this.dialogRef.close(this.dialgContactData);
    // }

}