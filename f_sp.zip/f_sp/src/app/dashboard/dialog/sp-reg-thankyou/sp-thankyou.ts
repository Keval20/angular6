import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { CommonService } from '../../../shared/common.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
    selector: 'sp-thankyouDialog',
    templateUrl: 'sp-thankyou.html',
    styleUrls: ['./sp-thankyou.css']
})
export class spThankyouDialog {
    userFormData = {};
    toastMessage: string;
    packageDeatils = {};
    packageId;
    dataq;
    showThankYou = false;
    language: String;
    cancelWithOutEdit;


    constructor(
        public dialogRef: MatDialogRef<spThankyouDialog>,
        private service: CommonService,
        private route: ActivatedRoute,
        private router: Router,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    ngOnInit() {
        this.language = this.service.getlanguage();
        console.log("in info::", this.language);
    }


    no(): void {
        this.dialogRef.close('no');
    }

    yes(): void {
        this.onSubmit(this.data.data)
        console.log("data123:", this.data.data)
    }

    showThankyou(): void {
        this.showThankYou = true
    }


    onSubmit(PackageForm) {
        console.log("Sp132::", PackageForm);
        this.packageId = PackageForm._id
        this.service.updatePackage('package/' + this.packageId, PackageForm).subscribe(
            data => { this.dataq = data; },
            err => { console.error(err); this.router.navigate(['error', '404']); },
            () => {
                this.showThankyou()
            }
        )

    }

    okay() {
        this.router.navigate(['auth/login']);
    }




}