import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


@Component({
    selector: 'servicesDialog',
    templateUrl: 'services.html',
    styleUrls: ['./services.css']
})
export class servicesDialog {

    canEdit = false;
    dialgContactData = {};
    cancelWithOutEdit;
    constructor(
        public dialogRef: MatDialogRef<servicesDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {
        console.log('contact diaglog', this.data)
    }

    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

    edit() {
        this.canEdit = true;

    }
    cancel(): void {
        this.canEdit = false;
    }

    save(): void {
        this.dialgContactData = {
            website: this.data.contactUsData['serviceProviderDocument']['contactInformation']['website'],
            facebook: this.data.contactUsData['serviceProviderDocument']['contactInformation']['facebook'],
            twitter: this.data.contactUsData['serviceProviderDocument']['contactInformation']['twitter'],
            instagram: this.data.contactUsData['serviceProviderDocument']['contactInformation']['instagram'],
        }
        this.dialogRef.close(this.dialgContactData);


    }
}