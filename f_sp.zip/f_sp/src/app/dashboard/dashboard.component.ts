import { Component, NgZone, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl } from '@angular/forms';

import { CommonService } from '../shared/common.service';
import { infoDialog } from './dialog/info/info';
import { contactDialog } from './dialog/contact/contact';
import { thankyouDialog } from './dialog/thankyou/thankyou';
import { servicesDialog } from './dialog/services/services';
import { packageInfoDialog } from './dialog/package_info/package_info';
import { replyOnCommentDialog } from './dialog/reply-on-comment/reply-on-comment'
import { bannerImageDialog } from './dialog/banner_image/banner_image';
import { } from 'googlemaps';
import { MapsAPILoader } from '@agm/core';
import { TranslateService } from '../translate.service';


@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],

})
export class DashboardComponent {
  myspid: any;
  dataSource: any;
  responseData: any;
  total;
  reviews;
  serviceTypeList;
  userFormData = {
    imageUrl: "",
    description: "",
    address:{
      city:"",
      state:"",
      country:"",
      zipCode:""
    }
  };
  infoData = {};
  contactUsData = {};
  replyOnCommentData = {};
  packageData = {};
  dataq: any;
  id: string;
  toastMessage: string;
  userId;
  comments = [];
  voucherDetails;
  parkingaccess: any = "false";
  language: String;


  public latitude: number;
  public longitude: number;
  public searchControl: FormControl;
  public zoom: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public service: CommonService,
    public dialog: MatDialog,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private translateService: TranslateService
  ) {

  }

  // language select function
  selectLanguage(str) {
    return this.translateService.selectLanguage(str);
  }


  @ViewChild("search")
  public searchElementRef: ElementRef;

  ngOnInit() {
    this.language = this.service.getlanguage();
    // console.log("lang132",this.language)
    //set google maps defaults
    this.zoom = 4;

    this.latitude = 25.2171003;
    this.longitude = 55.36136350000004;

    //create search FormControl
    this.searchControl = new FormControl();

    this.serviceTypeList = this.route.snapshot.data.serviceTypeList;
    this.userFormData = this.route.snapshot.data.getDetails;
    if (this.userFormData) {
      this.setCurrentPosition();
    }
    // this.userId = this.userFormData['user']['_id'];
    this.userId = this.userFormData['_id'];
    this.myspid = this.userFormData['myspid']

    // console.log(JSON.stringify(this.userFormData));

    this.parkingaccess = !this.parkingaccess;

    this.replyOnCommentData = {

    }
    this.reviews = this.route.snapshot.data.reviews;
    this.comments = this.route.snapshot.data.comments;
    this.voucherDetails = this.route.snapshot.data.vouchers;
  }

  fetch() {
    console.log("this is fetch() function");
    this.service.myPlan('service-provider/myplanq1').subscribe(
      data => {
        if (data) {
          this.responseData = data;
          console.log("responseData::", this.responseData)
        }
      },
      err => {
        console.error("err::", err)
      },
      () => {
        this.userFormData = this.responseData;

      }


    )

  }


  //** service provider details update */
  info() {
    let infoData = {
      "_serviceType": this.userFormData['_serviceType'],
      "parkingAccess": this.userFormData["parkingAccess"],
      "parkingMinutes": this.userFormData['parkingMinutes'],
      "wheelChairAccess": this.userFormData["wheelChairAccess"],
      "wifiAcces": this.userFormData["wifiAcces"],
      "openingTime": this.userFormData["openingTime"],
      "closingTime": this.userFormData["closingTime"],
      "description": this.userFormData["description"],


    }
    let dialogRef = this.dialog.open(infoDialog, {
      width: '600px',
      data: { message: 'Are you sure you want to delete this record ? ', infoData: infoData }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        this.saveModelData('info', result)
      } else {
        this.fetch();

      }

    });

  }

  //** contact info update  */
  contact() {
    let contactUsData = {
      "contactInformation": this.userFormData["contactInformation"],
      "name": this.userFormData["name"],
      "email": this.userFormData['contactInformation'].email,
      "phoneNumber": this.userFormData['contactInformation']["phoneNumber"],
      "lang": localStorage.getItem('lang')
    }
    let dialogRef = this.dialog.open(contactDialog, {
      width: '500px',
      data: { message: 'Are you sure you want to delete this record ? ', contactUsData: contactUsData }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        this.saveModelData('contact', result)
      } else {
        this.fetch();

      }
      console.log('The dialog was closed', result);
    });

  }


  services() {
    let dialogRef = this.dialog.open(servicesDialog, {
      width: '500px',
      data: { message: 'Are you sure you want to delete this record ? ' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        this.saveModelData('contact', result)
      }
      console.log('The dialog was closed', result);
    });
  }

  spServices() {
    this.router.navigate(['main/dashboard/services'])
  }


  review() {
    this.router.navigate(['main/dashboard/reviews'])
  }

  //** comment function */
  replyOnComment() {
    let dialogRef = this.dialog.open(replyOnCommentDialog, {
      width: '500px',
      data: { message: 'Are you sure you want to delete this record ? ', replyOnCommentData: this.replyOnCommentData }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        this.saveModelData('contact', result)
      }
      console.log('The dialog was closed', result);
    });

  }
  saveModelData(apienpoint: string, data: Object) {
    // console.log('inside validation onSubmit function')
    data['lang'] = localStorage.getItem('lang')
    var url = "service-provider/" + apienpoint
    this.service.update(url, data).subscribe(
      data => {
        if (data) {
          this.service.success(data.message, "Okay")
          this.fetch()
        }
      },
      err => { console.error('error found', err) },
    )
  }

  //** Banner Image show popup */
  bannerImageShow() {
    console.log("this.userFormData:", this.userFormData)
    let dialogRef = this.dialog.open(bannerImageDialog, {
      width: '650px',
      data: { message: 'Are you sure you want to delete this record ? ', data: this.userFormData, myspid: this.myspid }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        this.fetch()
        // this.saveModelData('contact', result)
      } else {
        this.fetch();
      }
      console.log('The dialog was closed', result);
    });

  }

  private setCurrentPosition() {
    this.latitude = +this.userFormData['address']['latitude'];
    this.longitude = +this.userFormData['address']['longitude'];
    this.zoom = 12;
  }


}




