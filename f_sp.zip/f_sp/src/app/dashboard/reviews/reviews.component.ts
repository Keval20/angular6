import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { Location } from '@angular/common';
import { replyOnCommentDialog } from '../dialog/reply-on-comment/reply-on-comment'
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TranslateService } from '../../translate.service';


@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
    public _location: Location,
    public dialog: MatDialog,
    private translateService: TranslateService,
  ) { }
  reviews;
  ngOnInit() {
    this.reviews = this.route.snapshot.data.reviews;
  }

  goBack() {
    this._location.back();
  }


  comment(review) {
    console.log(review);
    // this.router.navigate(['main/dashboard/review-replay']);
    let dialogRef = this.dialog.open(replyOnCommentDialog, {
      // height: '400px',
      width: '750px',
      data: { message: 'Are you sure you want to delete this record ? ', review: review }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {

      }
      console.log('The dialog was closed', result);
    });
  }

}
