import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard.component';
import { ReviewsComponent } from './reviews/reviews.component';
import { ReplyOnCommentComponent } from './reply-on-comment/reply-on-comment.component';

import { ServiceProviderResolverDetails } from './service-provider.resolverDetails'
import { ServiceProviderReviewResolverList } from './service-provider-review.resolverList';
import { PackageComponent } from './package/package.component';
import { PackageResolverDetails } from './package.resolverDetails';
import { PackageDescriptionResolverDetails } from './packageDescription.resolverDetails';
import { DashboardReviewsResolverDetails } from './dashboard-reviews.resolver';
import { BannerImagesComponent } from './banner-images/banner-images.component';
import { ServicesComponent } from './services/services.component';
import { ServicesResolverDetails } from './services.resolverDetails';
import { VouchersResolverDetails } from './vouchers.resolverDetails';




const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    resolve: {
      getDetails: ServiceProviderResolverDetails,
      reviews: ServiceProviderReviewResolverList,
      // vouchers: VouchersResolverDetails
    }
  },
  {
    path: 'reviews',
    component: ReviewsComponent,
    resolve: {
      reviews: ServiceProviderReviewResolverList,
      // comment: DashboardReviewsResolverDetails
    }
  },
  {
    path: 'review-replay',
    component: ReplyOnCommentComponent,
  },
  {
    path: 'package',
    component: PackageComponent,
    resolve: {
      getDetails: PackageResolverDetails,
      description: PackageDescriptionResolverDetails
    }
  },
  {
    path: 'banner-images',
    component: BannerImagesComponent,

  },
  {
    path: 'services',
    component: ServicesComponent,
    resolve: {
      // serviceDetails: ServiceProviderResolverDetails
    }
  },


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    ServiceProviderResolverDetails,
    ServiceProviderReviewResolverList,
    PackageDescriptionResolverDetails,
    PackageResolverDetails,
    DashboardReviewsResolverDetails,
    ServicesResolverDetails,
    VouchersResolverDetails
  ]
})
export class DashboardRoutingModule { }
