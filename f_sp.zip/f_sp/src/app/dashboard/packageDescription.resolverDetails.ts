import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map, tap, delay } from 'rxjs/operators';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CommonService } from '../shared/common.service';

@Injectable()

export class PackageDescriptionResolverDetails implements Resolve<any> {
    user: string;
    formData: FormData = new FormData();
    id;
    lang;
    constructor(
        private service: CommonService,
        private router: Router,
    ) { }
    resolve(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<any> {
        if (!localStorage.getItem('_id')) {
            this.router.navigate(['auth/login']);
        }
        this.id = localStorage.getItem('_id')
        this.lang = localStorage.getItem('lang')
        var url = 'packages/description/' + this.lang;
        return this.service.getDetails(url);

    }

}