import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map, tap, delay } from 'rxjs/operators';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CommonService } from '../shared/common.service';

@Injectable()

export class DashboardReviewsResolverDetails implements Resolve<any> {
    user: string;
    formData: FormData = new FormData();
    id;
    constructor(
        private service: CommonService,
        private router: Router,
    ) { }

    resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot) {
        let data;
        var url = 'review-and-rating/for-service-provider';
        if (!localStorage.getItem('_id')) {
            this.router.navigate(['auth/login']);
        } else {
            this.id = localStorage.getItem('_id');

            if (this.service.userIdForVoucher) {
                data = {
                    "_serviceProvider": localStorage.getItem('_id'),
                    "_user": this.service.userIdForVoucher
                }
            } else {
                data = {
                    "_serviceProvider": this.id,
                }
            }

        }


        return this.service.listPost(url, data)
    }

}