import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map, tap, delay } from 'rxjs/operators';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CommonService } from '../shared/common.service';

@Injectable()

export class ServicesResolverDetails implements Resolve<any> {
    user: string;
    formData: FormData = new FormData();
    id;
    constructor(
        private service: CommonService,
        private router: Router,
    ) { }
    resolve(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<any> {
        if (!localStorage.getItem('_id')) {
            this.router.navigate(['auth/login']);
        } else {
            this.service.dashboardData;
            console.log(' this.service.dashboardData;::', this.service.dashboardData)

        }
        this.id = localStorage.getItem('_id')
        var url = 'main-screen/service-provider-details/' + this.id;
        return this.service.getDetails(url);

    }

}