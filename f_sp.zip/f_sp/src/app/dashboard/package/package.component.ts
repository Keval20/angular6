import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { packageInfoDialog } from '../dialog/package_info/package_info';
import { thankyouDialog } from '../dialog/thankyou/thankyou';
import { TranslateService } from '../../translate.service';



@Component({
  selector: 'app-package',
  templateUrl: './package.component.html',
  styleUrls: ['./package.component.css']
})
export class PackageComponent implements OnInit {
  userFormData = {

    "voucherPackage": {
      "by_number": {
        "value": 0,
        "choice": false
      },
      "by_duration": {
        "value": 0,
        "choice": false
      }

    },


    "featureServices": {
      "main": false,
      "viewMore": false,
      "mainCount": 0,
      "viewMoreCount": 0

    },
    "whatsNew": {
      "main": false,
      "viewMore": false,
      "mainCount": 0,
      "viewMoreCount": 0
    },
    "healthPackage": {
      "main": false,
      "viewMore": false,
      "mainCount": 0,
      "viewMoreCount": 0
    },
    "emailMarketing": false,
    "socialMediaMarketing": false,
    "pushNotification": false



  }
  field_yes = true
  field_no = false
  description;
  goto;
  dataq;
  toastMessage: string;
  packageId;

  constructor(
    private route: ActivatedRoute,
    private service: CommonService,
    private router: Router,
    public dialog: MatDialog,
    private translateService: TranslateService,
  ) {
    this.goto = this.service.goto;
  }

  ngOnInit() {
    this.userFormData = this.route.snapshot.data.getDetails;

    // this.userFormData = {
    //   "_id": "5b44a153925e8635190111c1",
    //   "voucherPackage": {
    //     "by_number": {
    //       "choice": true
    //     },
    //     "by_duration": {
    //       "choice": true
    //     }
    //   },
    //   "featureServices": {
    //     "main": true,
    //     "viewMore": true
    //   },
    //   "whatsNew": {
    //     "main": true,
    //     "viewMore": true
    //   },
    //   "healthPackage": {
    //     "main": true,
    //     "viewMore": true
    //   },
    //   "pushNotification": true,
    //   "socialMediaMarketing": true,
    //   "emailMarketing": true,
    //   "status": "Pending",
    //   "_serviceProvider": "5b39f292b2e64a0e6063a3ca",
    //   "created_by": "5b39f292b2e64a0e6063a3ca",
    //   "updated_by": "5b39f292b2e64a0e6063a3ca",

    // }

    this.description = this.route.snapshot.data.description;
    this.packageId = this.userFormData['_id'];

    console.log('this.userFormData', this.userFormData);


  }
  // thankyou() {
  //   this.router.navigate(['main/dashboard/reviews'])
  // }

  packageInfo(pk: string) {
    let dialogRef = this.dialog.open(packageInfoDialog, {
      width: '450px',
      data: { message: 'Are you sure you want to delete this record ? ', description: this.description[pk] }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        // this.saveModelData('packageInfo', result)
      }

    });

  }

  onChangeToggleVoucherPackage(enable: boolean, stri: string, option: string) {
    if (enable) {
      this.userFormData[stri][option]["choice"] = this.field_yes
    } else {
      this.userFormData[stri][option]["choice"] = this.field_no
    }

  }
  onChangeToggleMain(enable: boolean, stri: string) {
    if (enable) {
      this.userFormData[stri]["main"] = this.field_yes
    } else {
      this.userFormData[stri]["main"] = this.field_no
    }

  }

  onChangeToggleviewMore(enable: boolean, stri: string) {
    if (enable) {
      this.userFormData[stri]["viewMore"] = this.field_yes
    } else {
      this.userFormData[stri]["viewMore"] = this.field_no
    }

  }

  onChangeToggleSingle(enable: boolean, stri: string) {
    if (enable) {
      this.userFormData[stri] = this.field_yes
    } else {
      this.userFormData[stri] = this.field_no
    }
  }


  thankyou() {
    let dialogRef = this.dialog.open(thankyouDialog, {
      width: '500px',
      data: { message: 'Are you sure you want to delete this record ? ', data: this.userFormData }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        // this.saveModelData('thankyou', result)
      }
      console.log('The dialog was closed', result);
    });
  }




}
