import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map, tap, delay } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CommonService } from '../shared/common.service';
@Injectable()

// newly added by vighnesh
export class DashboardResolverDetails implements Resolve<any> {
    user: string;
    formData: FormData = new FormData();
    id;
    constructor(
        private service: CommonService,
        private route: ActivatedRoute,
        private router: Router,

    ) { }
        resolve(
            route: ActivatedRouteSnapshot,
            state: RouterStateSnapshot
        ): Observable<any> {
            // this.id = route.paramMap.get('id');
            // this.id="5ade02095992b70474501bd0";
            // if (!localStorage.getItem('_id')) {
            //     this.router.navigate(['auth/login']);
            // }
            var url = 'admin/dashboard'
            return this.service.getDetails(url);
    
        }
}