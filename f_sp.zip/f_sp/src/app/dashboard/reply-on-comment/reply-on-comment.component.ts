import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-reply-on-comment',
  templateUrl: './reply-on-comment.component.html',
  styleUrls: ['./reply-on-comment.component.css']
})
export class ReplyOnCommentComponent implements OnInit {

  constructor(
    public _location: Location,
  ) { }

  ngOnInit() {
  }

  goBack() {
    this._location.back();
  }

}
