import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplyOnCommentComponent } from './reply-on-comment.component';

describe('ReplyOnCommentComponent', () => {
  let component: ReplyOnCommentComponent;
  let fixture: ComponentFixture<ReplyOnCommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReplyOnCommentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplyOnCommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
