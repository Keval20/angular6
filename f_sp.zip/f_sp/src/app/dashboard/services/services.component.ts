import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { MatDialog } from '@angular/material';
import { servicesInfoDialog } from '../dialog/services_info/services_info';
import { Location } from '@angular/common';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import {BehaviorSubject, Observable, of as observableOf} from 'rxjs';
import { TranslateService } from '../../translate.service';



@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  userFormData = {};
  services = [];
  language: String;
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
    public dialog: MatDialog,
    public _location: Location,
    private translateService: TranslateService,
  ) { }

  ngOnInit() {
    this.language = this.service.getlanguage();

    // this.userFormData = this.route.snapshot.data.serviceDetails._service;
    this.services = this.service.getClinicServices()
    console.log("this.userFormData::", JSON.stringify(this.services));
  }

  goBack() {
    this._location.back();
  }

  desctiption(serviceDesc) {
    console.log("serviceDesc::", serviceDesc);
    // this.router.navigate(['main/dashboard/review-replay']);
    let dialogRef = this.dialog.open(servicesInfoDialog, {
      // height: '400px',
      width: '550px',
      data: { message: 'Are you sure you want to delete this record ? ', data: serviceDesc }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {

      }
      console.log('The dialog was closed', result);
    });
  }


}
