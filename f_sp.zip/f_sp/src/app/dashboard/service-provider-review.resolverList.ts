import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
// import { ServiceTypesService } from './service-types.service';
import { catchError, map, tap, delay } from 'rxjs/operators';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CommonService } from '../shared/common.service';
@Injectable()

// newly added by vighnesh
export class ServiceProviderReviewResolverList implements Resolve<any> {
    id;
    constructor(
        private router: Router,
        private service: CommonService) { }
    resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot) {
        var url = 'review-and-rating/for-service-provider'
        if (!localStorage.getItem('_id')) {
            this.router.navigate(['auth/login']);
        }

        this.id = localStorage.getItem('_id')
        var data = {
            "_serviceProvider": this.id

        }

        return this.service.listPost(url, data)
    }
}