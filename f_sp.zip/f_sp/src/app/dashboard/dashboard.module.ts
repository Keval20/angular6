import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaterialModule } from '../shared/material/material.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { DashboardComponent } from './dashboard.component';
import { ReviewsComponent } from './reviews/reviews.component';
import { ReplyOnCommentComponent } from './reply-on-comment/reply-on-comment.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { PackageComponent } from './package/package.component';
import { BannerImagesComponent } from './banner-images/banner-images.component';
import { ServicesComponent } from './services/services.component';
import { AgmCoreModule } from '@agm/core';


@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    HttpClientModule,
    MaterialModule,
    FormsModule,
    AgmCoreModule.forRoot({
      apiKey: "AIzaSyCdUusWtmoAiyEp9rTPQDwwpFY4Y1tHHcw",
      libraries: ["places"]
    })
  ],
  declarations: [ DashboardComponent, ReviewsComponent, ReplyOnCommentComponent, PackageComponent, BannerImagesComponent, ServicesComponent],
})
export class DashboardModule { }
