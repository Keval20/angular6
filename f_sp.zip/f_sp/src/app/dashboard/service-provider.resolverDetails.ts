import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map, tap, delay } from 'rxjs/operators';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CommonService } from '../shared/common.service';
@Injectable()

// newly added by vighnesh
export class ServiceProviderResolverDetails implements Resolve<any> {
    user: string;
    id;
    formData: FormData = new FormData();
    constructor(
        private router: Router,
        private service: CommonService) { }
    resolve(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<any> {

        if (!localStorage.getItem('_id')) {
            this.router.navigate(['auth/login']);
        } else {
            this.id = localStorage.getItem('_id')
            // var url = 'service-provider/service-provider-details';
            // var url = 'main-screen/service-provider-details/' + this.id;
            var url = 'service-provider/myplanq1';
        }
        return this.service.myPlan(url)
    }
}