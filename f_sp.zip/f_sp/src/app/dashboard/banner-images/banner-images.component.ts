import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../../shared/common.service';


@Component({
  selector: 'app-banner-images',
  templateUrl: './banner-images.component.html',
  styleUrls: ['./banner-images.component.css']
})
export class BannerImagesComponent implements OnInit {

  image = [];
  fileToUpload: File;
  result: any;


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
  ) { }

  ngOnInit() {
  }

  @ViewChild('myInput')
  myInputVariable: ElementRef;

  Reset(img, index) {
    console.log("img", img)
    // this.image = []
    this.image.splice(index, 1);
    console.log(this.myInputVariable.nativeElement.files);
    this.myInputVariable.nativeElement.value = "";
    console.log(this.myInputVariable.nativeElement.files);
  }







  // removeLanguague(languague, index) {
  //   this.listOfLanguagues.splice(index, 1);
  // }
  // onSelectFile(event) {
  //   if (event.target.files && event.target.files[0]) {
  //     var reader = new FileReader();
  //     this.fileToUpload = event.target.files && event.target.files[0];
  //     reader.readAsDataURL(event.target.files[0]); // read file as data url

  //     reader.onload = (event: any) => { // called once readAsDataURL is completed
  //       this.image = event.target.result

  //     }
  //   }
  // }

  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();

        reader.onload = (event: any) => {
          console.log(event.target.result);
          this.image.push(event.target.result);
        }

        reader.readAsDataURL(event.target.files[i]);
      }
    }
  }



}
