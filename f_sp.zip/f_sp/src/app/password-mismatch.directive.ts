import { Directive, Attribute } from '@angular/core';
import { AbstractControl, FormGroup, NG_VALIDATORS, ValidationErrors, Validator, ValidatorFn } from "@angular/forms";


function validatePassword(): ValidatorFn {
  return (control: AbstractControl) => {
    let isValid = false;
    if (control && control instanceof FormGroup) {
      let group = control as FormGroup;
      if (group.controls['password'] && group.controls['confirmPassword']) {
        isValid = group.controls['password'].value == group.controls['confirmPassword'].value;
      }
    }
    if (isValid) {
      return null;
    } else {
      return { 'passwordCheck': 'failed' }
    }
  }
}


@Directive({
  selector: '[appCheckPassword]',
  providers: [{ provide: NG_VALIDATORS, useExisting: CompareDirective, multi: true }]
})
// @Directive({
//   selector: '[advs-compare]',
//   providers: [{ provide: NG_VALIDATORS, useExisting: CompareDirective, multi: true }]
// })
export class CompareDirective {

  private valFn;

  constructor() {
    this.valFn = validatePassword();
  }

  validate(c: AbstractControl): ValidationErrors | null {
    return this.valFn(c);
  }



  // constructor(@Attribute('advs-compare') public comparer: string,
  //             @Attribute('parent') public parent: string){}

  // validate(c: FormControl): {[key: string]: any} {
  //   let e = c.root.get(this.comparer);

  //   // value not equal in verify control
  //   if (e && c.value !== e.value && !this.isParent) {
  //     return {"compare": true};
  //   }

  //   // user typing in password and match
  //   if (e && c.value === e.value && this.isParent) {
  //       delete e.errors['compare'];
  //       if (!Object.keys(e.errors).length) e.setErrors(null);
  //   }

  //   // user typing in password and mismatch
  //   if (e && c.value !== e.value && this.isParent) {
  //       e.setErrors({ "compare": true });
  //   }
  // }

  // private get isParent() {
  //   if (!this.parent) 
  //     return false;

  //   return this.parent === 'true' ? true: false;
  // }
}
