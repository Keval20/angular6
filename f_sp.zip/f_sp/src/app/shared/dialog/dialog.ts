import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'dialog-overview-example-dialog',
    templateUrl: 'dialog.html',
})
export class DialogOverviewExampleDialog {

    constructor(
        public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    yes(): void {
        this.dialogRef.close('yes');
    }
    no(): void {
        this.dialogRef.close('no');
    }

}