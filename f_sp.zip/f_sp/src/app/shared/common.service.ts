import { Injectable } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpClientModule } from '@angular/common/http';
import { MatSnackBar } from '@angular/material';
import { catchError, tap, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { TranslateService } from '../translate.service';

@Injectable({
  providedIn: 'root'
})


export class CommonService {
  signinData: any;
  dashboardData: any;
  callingCode;
  constructor(
    private router: Router,
    public _location: Location,
    private http: HttpClient,
    public snackBar: MatSnackBar,
    private translateService: TranslateService
  ) { }


  // public apiendpoint = "http://fleekalive.xceltec.com:5050/api/";
  // public filePath = "http://fleekalive.xceltec.com:5050/files/";


  // public apiendpoint = "http://fleekaalive.xceltec.com:5050/api/";
  // public filePath = "http://fleekaalive.xceltec.com:5050/files/";

  // public apiendpoint = "http://fleeka.xceltec.com:5051/api/";
  // public filePath = "http://fleeka.xceltec.com:5051/files/";

  public apiendpoint = "http://api.fleeka.ae:5050/api/";
  public filePath = "http://api.fleeka.ae:5050/files/";

  

  // pagination defult options
  pageIndex: Number = 0;
  pageSize: Number = 5;
  pageSizeOptions: Number[] = [5, 10, 15, 20, 25, 30];
  activeToolTipe: string = "Deactivate This Account"
  public response;
  public clinic_name: string = 'testone';
  public clinic_img: string = 'defult.jpg';
  public language: string = "en";
  public userIdForVoucher: String;
  public handleError1Old<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  //** Error handling function */
  public handleError1<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.error(error.error.message, '')
      this.log(`${operation} failed: ${error.error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }


  private log(message: string) {
    console.log('message::', message)
  }

  selectLanguage(str) {
    return this.translateService.selectLanguage(str);
  }


  handleError(error: HttpErrorResponse) {
    console.log('error', error)
    if (error.status == 401) {
      localStorage.clear()

    }
    // this.router.navigate(['error', error.status])
    return of(error || "500")
  }

  error(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 4000,
      verticalPosition: 'top',
      horizontalPosition: 'center',
    });

  }

  goto(url) {
    this.router.navigate([url])
  }
  goBack() {
    this._location.back();

  }

  success(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 4000,
      verticalPosition: 'top',
      horizontalPosition: 'center',
    });
    // this.toastr.success('Hello world!', 'Toastr fun!')

  }


  listPost(apipoint: string, data) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + apipoint, data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          if (this.response.code == 200) {
          } else {
            // this.error(this.response.message, '')
          }
        }),
        catchError(this.handleError)
      );

  }

  list(apipoint: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.get(this.apiendpoint + apipoint, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          if (this.response.code == 200) {
          } else {
            this.error(this.response.message, '')
          }
        }),
        catchError(this.handleError)
      );

  }

  getDetails(apipoint: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.get(this.apiendpoint + apipoint, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;

          if (this.response.code == 200) {
          } else {
            // this.common.error(this.response.message, '')
          }
        }),
        catchError(this.handleError)
      );

  }
  //** for service provider details */
  myPlan(apipoint: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.get(this.apiendpoint + apipoint, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          this.dashboardData = reponseData;
          if (this.response.code == 200) {
          } else {
            // this.common.error(this.response.message, '')
          }
        }),
        catchError(this.handleError)
      );

  }

  getVoucher(apipoint: string) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.get(this.apiendpoint + apipoint, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          if (this.response.code == 200) {
          } else {
            // this.common.error(this.response.message, '')
          }
        }),
        catchError(this.handleError)
      );

  }
  status(apipoint: string, data) {
    return this.http.post(this.apiendpoint + apipoint, data)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          if (this.response.code == 200) {
            this.success(this.response.message, 'Okay')
          } else {
            this.error(this.response.message, 'Okay')
          }
        }),
        catchError(this.handleError)
      );
  }
  delete(apipoint: string, data) {
    return this.http.post(this.apiendpoint + apipoint, data)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          if (this.response.code == 200) {
            this.success(this.response.message, 'Okay')
          } else {
            this.error(this.response.message, 'Okay')
          }
        }),
        catchError(this.handleError)
      );
  }

  loginWith1(data) {
    return this.http.post(this.apiendpoint + 'signin', data)
      .pipe(
        tap((reponseData: any) => {
          console.log(reponseData)
          this.response = reponseData;
          console.log(`${this.response.headers.get('x-auth')}`);
          console.log('service response: ', this.response.json());
          localStorage.setItem('auth', `${this.response.headers.get('x-auth')}`);
        }),
        catchError(this.handleError)
      );
  }
  loginWith(data) {
    return this.http.post(this.apiendpoint + 'signin', data, {
      observe: 'response'
    }).pipe(
      tap((reponseData: any) => {
        console.log(reponseData)
        this.response = reponseData;
        this.signinData = reponseData;
        console.log(`${this.response.headers.get('x-auth')}`);
        localStorage.setItem('auth', `${this.response.headers.get('x-auth')}`);
        localStorage.setItem('_id', this.response.body._id);
        localStorage.setItem('lang', (this.translateService.getLanguage()) ? this.translateService.getLanguage() : 'en');
      }),
      catchError(this.handleError)
    );

  }

  changePassword(data) {
    console.log("data123::", data)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + 'user/change-password-new', data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
    // .pipe(
    //   tap((reponseData: any) => {
    //     this.response = reponseData;
    //     if (this.response.code == 200) {
    //       this.success(this.response.message, 'Okay')
    //     } else {
    //       console.log('error changePassword')

    //       this.error(this.response.message, 'Okay')
    //     }
    //   }),
    //   catchError(this.handleError)
    // );
  }

  update(apipoint: string, data) {
    const httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.put(this.apiendpoint + apipoint, data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
    // .pipe(
    //   tap((reponseData: any) => {
    //     this.response = reponseData;
    //     if (this.response.code == 200) {
    //       this.success(this.response.message, 'Okay')
    //     } else {
    //       this.error(this.response.message, 'Okay')
    //     }
    //   }),
    //   catchError(this.handleError)
    // );
  }


  add(apipoint: string, data) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + apipoint, data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
    // .pipe(
    //   tap((reponseData: any) => {
    //     this.response = reponseData;
    //     if (this.response.code == 200) {
    //       this.success(this.response.message, 'Okay')
    //     } else {
    //       this.error(this.response.message, 'Okay')
    //     }
    //   }),
    //   catchError(this.handleError)
    // );
  }

  cmsCommon(data) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + 'cms/identity', data, httpOptions)

      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
  }

  //** Service Provider Signup  */
  signupAdd(apipoint: string, data) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Access-Control-Allow-Origin': "*",
        // 'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + apipoint, data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );

  }

  bannerImage(apipoint: string, data) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + apipoint, data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );

  }

  addFormData(apipoint: string, data) {
    const httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': 'multipart/form-data',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + apipoint, data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;

        }),
        catchError(this.handleError1<any>('errorWhileAdd'))

      );

  }



  //** forget password function */
  forgetPassword(data) {
    console.log("data123::", data)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",

      })
    };
    return this.http.post(this.apiendpoint + 'signup/forget-password', data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
  }

  //** logout function */
  logout() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.delete(this.apiendpoint + 'signout', httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          localStorage.clear();
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
  }

  //** Update Package (Quotation) */
  updatePackage(apipoint: string, data) {
    const httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.put(this.apiendpoint + apipoint, data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
    // .pipe(
    //   tap((reponseData: any) => {
    //     this.response = reponseData;
    //     console.log('updatePackage common', this.response)

    //   }),
    //   catchError(this.handleError)
    // );
  }

  //** Change language function */
  changeLangugage(data) {
    console.log("data123::", data)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + 'user/change-language', data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
  }

  //** change Currency function */
  changeCurrency(data) {
    console.log("data123::", data)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.post(this.apiendpoint + 'user/change-currency', data, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
  }

  //** change activation pin function */
  changeactivationPin(data) {
    var changePing = {
      "serviceProviderID": localStorage.getItem("_id"),
      "activationPin": data.activationPin,
      'lang': localStorage.getItem('lang')
    }
    // console.log("data123::", changePing)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth'),

      })
    };
    return this.http.put(this.apiendpoint + 'service-provider/update-pin', changePing, httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
  }

  //** Deactivate Account function */
  deactivateAccount() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'Access-Control-Allow-Origin': "*",
        'x-auth': localStorage.getItem('auth')
      })
    };
    return this.http.get(this.apiendpoint + 'user/deactivate', httpOptions)
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          localStorage.clear();
        }),
        catchError(this.handleError1<any>('errorWhileAdd'))
      );
    // .pipe(
    //   tap((reponseData: any) => {
    //     this.response = reponseData;
    //     if (this.response.code == 200) {
    //       this.success(this.response.message, 'Okay')
    //     } else {
    //       console.log('error change language')

    //       this.error(this.response.message, 'Okay')
    //     }
    //   }),
    //   catchError(this.handleError)
    // );
  }

  // spregister(apipoint: string, data) {

  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       // 'Content-Type': 'application/json; charset=UTF-8',
  //       // 'Access-Control-Allow-Origin': "*",
  //       // 'x-auth': localStorage.getItem('auth')
  //     })
  //   };
  //   return this.http.post(this.apiendpoint + apipoint, data)
  //     .pipe(
  //       tap((reponseData: any) => {
  //         this.response = reponseData;
  //         console.log('updatePackage common', this.response)

  //       }),
  //       catchError(this.handleError)
  //     );
  // }


  // 15_08_2018 start
  getClinicName(): String {
    if (this.dashboardData) {
      this.clinic_name = this.dashboardData;
      return this.clinic_name;
    } else {
      return this.clinic_name;
    }
  }

  getClinicImg(): String {
    if (this.dashboardData) {
      this.clinic_img = this.dashboardData['imageUrl'];
      return this.clinic_img;
    } else {
      return this.clinic_img;
    }
  }

  getClinicServices(): Array<any> {
    let services = []
    if (this.dashboardData) {
      services = this.dashboardData['_service'];
      return services;
    } else {
      return services;
    }
  }

  getlanguage(): String {
    this.language = localStorage.getItem('lang');
    if (this.language) {
      return this.language;
    } else {
      return this.language;
    }
    // return this.language;
  }


  //** Country calling code api */
  // https://restcountries.eu/rest/v2/all

  getCountryCode() {
    return this.http.get("http://restcountries.eu/rest/v2/all")
      .pipe(
        tap((reponseData: any) => {
          this.response = reponseData;
          console.log("This is getCountryCode if part", this.response)
        }),
        catchError(this.handleError)
      );

  }

}
