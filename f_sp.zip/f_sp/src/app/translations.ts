export const TRANSLATIONS = [
  // Login page
  {
    en: "Login",
    ar: 'تسجيل الدخول'
  },
  {
    en: "Don't have an account?",
    ar: 'ليس لديك حساب ؟'
  },
  {
    en: "Forgot Password?",
    ar: 'هل نسيت كلمه المرور؟'
  },
  {
    en: "Register Now",
    ar: 'التسجيل الآن'
  },
  {
    en: "Please enter your email",
    ar: 'الرجاء إدخال كلمه المرور'
  },
  {
    en: "Not a valid email",
    ar: 'بريد الكتروني غير صحيح'
  },


  // Registration page
  {
    en: "Register",
    ar: 'تسجيل'
  },
  {
    en: "Already have an Account?",
    ar: 'هل لديك حساب بالفعل ؟'
  },
  {
    en: 'By clicking "REGISTER" I agree to Terms & Condition',
    ar: 'بالنقر فوق "تسجيل " أوافق علي الشروط والاحكام'
  },
  {
    en: "Establishment Name",
    ar: 'اسم المؤسسة'
  },
  {
    en: "Name of User",
    ar: 'اسم المستخدم'
  },
  {
    en: "Enter your email",
    ar: 'ادخل بريدك الكتروني'
  },
  {
    en: "Enter your Phone Number",
    ar: 'ادخل رقم هاتفك'
  },
  {
    en: 'Enter password',
    ar: 'ادخل كلمه المرور'
  },
  {
    en: 'Enter confirm password',
    ar: 'ادخل تاكيد كلمه المرور'
  },
  {
    en: 'You must enter a value',
    ar: 'يجب إدخال قيمه'
  },
  {
    en: 'Your phone cannot exceed 50 characters.',
    ar: 'لا يمكن ان يتجاوز هاتفك 50 حرفا.'
  },
  {
    en: 'This email address is invalid',
    ar: 'عنوان البريد الكتروني هذا غير صالح'
  },
  {
    en: 'Your phone must be at least 10 characters long.',
    ar: 'يجب الا يقل طول هاتفك عن 10 أحرف.'
  },
  {
    en: 'Your phone must be at least 9 characters long.',
    ar: 'يجب الا يقل طول هاتفك عن 9 أحرف.'
  },
  {
    en: 'Your phone cannot exceed 16 digit.',
    ar: 'لا يمكن ان يتجاوز هاتفك 16 رقما.'
  },
  {
    en: 'Please enter password',
    ar: 'الرجاء إدخال كلمه المرور'
  },
  {
    en: 'Password must be at least 6 characters long.',
    ar: 'يجب ان يكون طول كلمه المرور 6 أحرف علي الأقل.'
  },
  {
    en: 'Password cannot exceed 15 characters.',
    ar: 'لا يمكن ان تتجاوز كلمه المرور 15 حرفا.'
  },
  {
    en: 'Please enter confirm password',
    ar: 'الرجاء إدخال تاكيد كلمه المرور'
  },
  {
    en: 'Password and Confirm password are not equal',
    ar: 'كلمه المرور وتاكيد كلمه المرور ليست متساوية'
  },
  {
    en: 'Service Provider',
    ar: 'مزود الخدمة'
  },
  {
    en: 'Upload Photo',
    ar: 'تحميل الصور'
  },

  // After login page
  {
    en: 'Dashboard',
    ar: 'لوحه القياده'
  },
  {
    en: 'Profile',
    ar: 'الشخصيه'
  },
  {
    en: 'Voucher Status',
    ar: 'حاله القسيمة'
  },
  {
    en: 'Package',
    ar: 'حزمه'
  },
  {
    en: 'How it works',
    ar: 'كيف يعمل'
  },
  {
    en: 'Settings',
    ar: 'اعدادات'
  },
  {
    en: 'About Us',
    ar: 'من نحن'
  },
  {
    en: 'About', 
    ar: 'عن'
  },
  {
    en: "FAQ's",
    ar: 'اسئله وأجوبه'
  },
  {
    en: "Contact Us",
    ar: 'اتصل بنا'
  },
  // Dashboard page
  {
    en: "Logout",
    ar: 'تسجيل الخروج'
  },
  {
    en: "Fleeka",
    ar: 'فليكا'
  },
  {
    en: "Info",
    ar: 'معلومات'
  },
  {
    en: "Contact",
    ar: 'الاتصال'
  },
  {
    en: "Reviews & Ratings",
    ar: 'التعليقات والتقييمات'
  },
  {
    en: "Services",
    ar: 'خدمات'
  },
  {
    en: "Forgot password",
    ar: 'نسيت كلمه المرور'
  },
  {
    en: "SUBMIT",
    ar: 'إرسال'
  },
  {
    en: "Description",
    ar: 'وصف'
  },
  {
    en: "No description added!",
    ar: 'لا يوجد وصف المضافة!'
  },
  {
    en: "Type of Service",
    ar: "نوع الخدمة"
  },
  {
    en: "PARKING MINUTES",
    ar: 'دقائق وقوف السياراتs'
  },
  {
    en: 'PHONE NUMBER',
    ar: 'رقم الهاتف'
  },
  {
    en: 'EMAIL',
    ar: 'البريد الالكتروني'
  },
  {
    en: 'WEBSITE',
    ar: 'الموقع'
  },
  {
    en: 'FACEBOOK',
    ar: 'ف يسبوك'
  },
  {
    en: 'TWITTER',
    ar: 'التغريد'
  },
  {
    en: 'INSTAGRAM',
    ar: 'اينستاجرام'
  },
  {
    en: "Please enter phone Number",
    ar: 'الرجاء إدخال رقم الهاتف'
  },
  {
    en: "Please enter minimum 10 numbers",
    ar: 'الرجاء إدخال 10 أرقام كحد ادني'
  },
  {
    en: "Please enter email",
    ar: 'الرجاء إدخال البريد الكتروني'
  },
  {
    en: "Reviews",
    ar: 'ملاحظات'
  },
  {
    en: 'Review',
    ar: 'استعراض'
  },
  {
    en: "No Data Found",
    ar: 'لم يتم العثور علي بيانات'
  },
  {
    en: "Services Details",
    ar: 'تفاصيل الخدمات'
  },
  {
    en: "Voucher Status",
    ar: 'حاله القسيمة'
  },
  {
    en: "Unused voucher",
    ar: 'القسيمة غير المستخدمة'
  },
  {
    en: "Please enter website",
    ar: 'الرجاء إدخال الموقع'
  },
  {
    en: "out of",
    ar: 'من'
  },
  {
    en: "Current Reserved Voucher",
    ar: 'القسيمة المحجوزة الحالية'
  },
  {
    en: "Current Activated Voucher",
    ar: 'القسيمة المفعلة حاليا'
  },
  {
    en: "Current Expired Voucher",
    ar: 'القسيمة منتهية الصلاحية'
  },
  {
    en: "Unused",
    ar: 'غير مستخدمه'
  },
  {
    en: "Reserved",
    ar: 'محفوظه'
  },
  {
    en: "Used",
    ar: 'استخدام'
  },
  {
    en: "Expired",
    ar: 'انتهت'
  },
  {
    en: "Per Voucher",
    ar: 'لكل قسيمة'
  },
  {
    en: "Per Voucher",
    ar: 'لكل قسيمة'
  },
  {
    en: "What's a new section",
    ar: 'ما هو القسم الجديد'
  },
  {
    en: "Push Notification",
    ar: 'دفع الاخطار'
  },
  {
    en: "Please enter current password",
    ar: 'الرجاء إدخال كلمه المرور الحالية'
  },
  {
    en: "Upload Image",
    ar: 'تحميل صوره'
  },
  {
    en: "to",
    ar: 'ل'
  },
  {
    en: "My Profile",
    ar: 'ملفي الشخصي'
  },
  {
    en: "Please enter your password",
    ar: 'الرجاء إدخال كلمه المرور'
  },
  { en: "Dashboard", ar: "لوحه القياده" },
  { en: "Voucher Status", ar: "حاله القسيمة" },
  { en: "Package", ar: "حزمه" },
  { en: "How it works", ar: "كيف يعمل" },
  { en: "Settings", ar: "اعدادات" },
  { en: "About Us", ar: "من نحن" },
  { en: "FAQ's", ar: "اسئله وأجوبه" },
  { en: "Contact Us", ar: "اتصل بنا" },
  { en: "Profile", ar: "الشخصيه" },




  //Darshita Changes
  {
    en: "Please enter email",
    ar: 'الرجاء إدخال البريد الكتروني'
  },
  {
    en: "Please enter website",
    ar: 'الرجاء إدخال الموقع'
  },
  {
    en: "Please enter facebook",
    ar: 'الرجاء إدخال الفيسبوك'
  },
  {
    en: "Please enter twitter",
    ar: 'يرجى إدخال تويتر'
  },
  {
    en: "Please enter instagram",
    ar: 'الرجاء إدخال اينستاجرام'
  },
  {
    en: "Please enter valid website",
    ar: 'الرجاء إدخال موقع الويب الصحيح'
  },
  {
    en: "Please enter valid facebook link",
    ar: 'الرجاء إدخال رابط الفيسبوك صالح'
  },
  {
    en: "Please enter valid twitter link",
    ar: 'الرجاء إدخال رابط تويتر صالح'
  },
  {
    en: "Please enter valid instagram link",
    ar: 'الرجاء إدخال وصله اينستاجرام صالحه'
  },
  {
    en: "LOCATION",
    ar: 'موقع'
  },
  {
    en: "COUNTRY",
    ar: 'البلد'
  },
  {
    en: "STATE",
    ar: 'الدوله'
  },
  {
    en: "CITY",
    ar: 'المدينه'
  },
  {
    en: "ZIPCODE",
    ar: 'الرمز البريدي'
  },
  {
    en: "You must enter a numbers",
    ar: 'يجب إدخال أرقام'
  },
  {
    en: "CURRENT PASSWORD",
    ar: 'كلمه السر الحالية'
  },
  {
    en: "Please enter current password",
    ar: 'الرجاء إدخال كلمه المرور الحالية'
  },
  {
    en: "Password should be 8 characters long",
    ar: 'يجب ان يكون طول كلمه المرور 8 أحرف'
  },
  {
    en: "Password not match to New Password",
    ar: 'كلمه المرور غير متطابقة مع كلمه المرور الجديدة'
  },
  {
    en: "Change Password",
    ar: 'تغيير كلمه المرور'
  },
  {
    en: "NEW PASSWORD",
    ar: 'كلمه السر الجديدة'
  },
  {
    en: "Please enter new password",
    ar: 'الرجاء إدخال كلمه المرور الجديدة'
  },
  {
    en: "Your password must be at least 6 characters long.",
    ar: 'يجب ان يكون طول كلمه المرور 6 أحرف علي الأقل.'
  },
  {
    en: "Password Cannot Exceed 15 Characters.",
    ar: ' لا يمكن ان تتجاوز كلمه المرور 15 حرفا.'
  },
  {
    en: "CONFIRM NEW PASSWORD",
    ar: 'تاكيد كلمه السر الجديدة'
  },
  {
    en: "Please enter confirm new password",
    ar: 'الرجاء إدخال تاكيد كلمه المرور الجديدة'
  },
  {
    en: "New password and Confirm new password must be equal",
    ar: 'يجب ان تكون كلمه المرور الجديدة وتاكيد كلمه المرور الجديدة متساوية'
  },
  {
    en: "Update",
    ar: 'تحديث'
  },
  {
    en: "Update Activation Pin",
    ar: 'تحديث دبوس التنشيط'
  },
  {
    en: "ACTIVATION PIN",
    ar: 'تفعيل الرقم السري'
  },
  {
    en: "ACTIVATION PIN",
    ar: 'تفعيل الرقم السري'
  },
  {
    en: "Please enter activation pin",
    ar: 'الرجاء إدخال دبوس التنشيط'
  },
  {
    en: "Activation Pin should be 4 number long",
    ar: 'يجب ان يكون دبوس التنشيط 4 عدد طويل'
  },
  {
    en: "Language",
    ar: 'اللغه'
  },
  {
    en: "English",
    ar: 'الإنكليزية'
  },
  {
    en: "Arabic",
    ar: 'العربية'
  },
  {
    en: "Change Pin",
    ar: 'تغيير الدبوس'
  },
  {
    en: "Privacy Policy",
    ar: 'سياسة الخصوصية'
  },
  {
    en: "Terms and Condition",
    ar: 'الشروط والاحكام'
  },
  {
    en: "Deactivate Account",
    ar: 'إلغاء تنشيط الحساب'
  },
  {
    en: "If you want to Deactivate account",
    ar: 'إذا كنت ترغب في إلغاء تنشيط الحساب'
  },
  {
    en: "Click here",
    ar: 'اضغط هنا'
  },
  {
    en: "Feature Services",
    ar: 'الخدمات المميزة'
  },

  //profile//
  {
    en: "FIRST NAME",
    ar: 'الاسم الأول'
  },
  {
    en: "LAST NAME",
    ar: 'اسم العائلة'
  },
  {
    en: "EMAIL",
    ar: 'البريد الالكتروني'
  },
  {
    en: "USER ACCOUNT",
    ar: 'حساب المستخدم'
  },
  {
    en: "Reserved on",
    ar: 'محجوز علي'
  },
  {
    en: "Expired on",
    ar: 'انتهت صلاحيتها في'
  },
  {
    en: "Activated on",
    ar: 'تنشيط علي'
  },
  {
    en: "Used on",
    ar: 'يستخدم علي'
  },
  {
    en: "Discount",
    ar: 'الخصم'
  },
  {
    en: "Okay",
    ar: 'حسنًا'
  },
  {
    en: "Would you like to proceed",
    ar: 'هل ترغب في المتابعة'
  },
  {
    en: "A member of fleeka will contact you shortly to finalize your package",
    ar: 'سيتصل بك عضو من "فليكا" قريبا لوضع اللمسات النهائية علي باقتك'
  },
  {
    en: "Reply on this Comment:",
    ar: 'الرد علي هذا التعليق:'
  },
  {
    en: "User Review:",
    ar: 'استعراض المستخدم:'
  },
  {
    en: "Are you sure you want to Deactivate This Account ?",
    ar: 'هل تريد بالتاكيد إلغاء تنشيط هذا الحساب ؟'
  },
  {
    en: "Location is not added",
    ar: 'لم يتم أضافه الموقع'
  },
  {
    en: "Your Registration is under review and a member of fleeka will contact you shortly",
    ar: 'التسجيل الخاص بك هو قيد المراجعة سيقوم عضو من فليكا بالاتصال بك قريبا'
  },
  {
    en: "Note :",
    ar: 'ملاحظه:'
  },
  {
    en: "Banner images will display to fleeka user after activated by Fleeka administration.",
    ar: 'سيتم عرض صور بانر لمستخدم فليكا بعد تنشيطه من قبل أداره فليكا.'
  },

  //
  {
    "en": "Sign Up Later",
    "ar": "التسجيل لاحقا"
  },
  {
    "en": "Beauty on fleek",
    "ar": "الجمال المتكامل"
  },
  {
    "en": "Don't have an Account?",
    "ar": "لا يوجد لديك حساب"
  },
  {
    "en": "Register Now",
    "ar": "التسجيل الآن"
  },
  {
    "en": "Need Help ?",
    "ar": "تحتاج مساعده؟"
  },
  {
    "en": "Forgot Password?",
    "ar": "هل نسيت كلمه المرور؟"
  },
  {
    "en": "User Name",
    "ar": "إسم المستخدم"
  },
  {
    "en": "Password",
    "ar": "كلمه المرور"
  },
  {
    "en": "LOGIN",
    "ar": "الدخول"
  },
  {
    "en": "Login via Facebook",
    "ar": "الدخول عن طريق حساب  فيسبوك"
  },
  {
    "en": "Login via Google",
    "ar": "الدخول عن طريق حساب جوجل"
  },
  {
    "en": "SIGN UP",
    "ar": "التسجيل"
  },
  {
    "en": "User",
    "ar": "المستخدم"
  },
  {
    "en": "SERVICE PROVIDER",
    "ar": "مقدم الخدمه"
  },
  {
    "en": "Upload Photo",
    "ar": "تحميل صوره"
  },
  {
    "en": "Confirm Password",
    "ar": "تأكيد كلمه السر"
  },
  {
    "en": "REGISTER",
    "ar": "تسجيل"
  },
  {
    "en": "By clicking \"REGISTER\" I agree to Terms & Conditions",
    "ar": "عند الضغط على \"تسجيل\" أوافق على جميع الشروط."
  },
  {
    "en": "Log In",
    "ar": "دخول"
  },
  {
    "en": "Your PIN",
    "ar": "الرمز الخاص فيك"
  },
  {
    "en": "Your Service",
    "ar": "الخدمه الخاصه لك"
  },
  {
    "en": "Settings",
    "ar": "الإعدادات"
  },
  {
    "en": "Health_Tourism",
    "ar": "السياحه العلاجيه"
  },
  {
    "en": "Currency",
    "ar": "العمله"
  },
  {
    "en": "Info",
    "ar": "معلومات"
  },
  {
    "en": "Contact",
    "ar": "الشخص المعني"
  },
  {
    "en": "Reviews & Ratings",
    "ar": "مرجعات وتقييمات"
  },
  {
    "en": "Dubai - JLT",
    "ar": "دبي-أبراج بحيرات جميره"
  },
  {
    "en": "Service Provider Default Name",
    "ar": "إسم مقدم الخدمه"
  },
  {
    "en": "View All >>",
    "ar": "عرض الجميع"
  },
  {
    "en": "PROCEED TO CHECK OUT",
    "ar": "إتمام عمليه الشراء"
  },
  {
    "en": "Types of Services",
    "ar": "أنواع الخدمات"
  },
  {
    "en": "Unlimited Vouchers",
    "ar": "قسائم غير محدوده"
  },
  {
    "en": "Social Media Marketing",
    "ar": "التسويق من خلال تطبيقات التواصل الاجتماعي"
  },
  {
    "en": "Email Marketing",
    "ar": "التسويق من خلال البريد الإلكتروني"
  },
  {
    "en": "Offer of the Month",
    "ar": "عروض الشهر الحالي"
  },
  {
    "en": "Whats New Section",
    "ar": "قسم \"ماهو جديد\""
  },
  {
    "en": "Would you like to Proceed",
    "ar": "هل ترغب في المتابعة"
  },
  {
    "en": "A member of fleeka will contact you shortly to finalize your Package",
    "ar": "أحد موظفين فليكا سوف يتواصل معك "
  },
  {
    "en": "Yes",
    "ar": "نعم"
  },
  {
    "en": "No",
    "ar": "لا"
  },
  {
    "en": "OK",
    "ar": "أوافق"
  },
  {
    "en": "Thank You !",
    "ar": "شكرا!"
  },
  {
    "en": "EDIT",
    "ar": "تحرير"
  },
  {
    "en": "SAVE",
    "ar": "حفظ"
  },
  {
    "en": "CANCEL",
    "ar": "إلغاء الأمر"
  },
  {
    "en": "Parking Access",
    "ar": "الوصول إلى مواقف السيارات"
  },
  {
    "en": "Parking Minutes",
    'ar': "دقائق وقوف السيارات"
  },
  {
    "en": "Wheelchair Access",
    "ar": "دخول الكراسي المتحركة"
  },
  {
    "en": "Wifi Access",
    "ar": "وأي فاي الوصول"
  },
  {
    "en": "Opening Hours",
    "ar": "ساعات العمل"
  },
  {
    "en": "Something went wrong. Please try again later.",
    "ar": "هناك خطأ يرجى المحاوله لاحقاً"
  },
  {
    "en": "Top Ratings",
    "ar": "أعلي التقييمات"
  },
  {
    "en": "Old Password",
    "ar": "كلمه المرور القديمه"
  },
  {
    "en": "en",
    "ar": "آنجليزي"
  },
  {
    "en": "ar",
    "ar": "عربي"
  },
  {
    "en": "Top Deal",
    "ar": "أفضل العروض"
  },
  {
    "en": "What's New",
    "ar": "ماهو جديد"
  },
  {
    "en": "Select Service",
    "ar": "آختيار خدمه"
  },
  {
    "en": "Voucher Packages",
    "ar": "قسائم"
  },
  {
    "en": "Voucher Package",
    "ar": "قسيمه"
  },
  {
    "en": "Login",
    "ar": "الدخول"
  },
  {
    "en": "Main Screen",
    "ar": "الشاشه الرئيسيه"
  },
  {
    "en": "View More Screen",
    "ar": "شاشه عرض المزيد"
  },
  {
    "en": "Social Media Marketing",
    "ar": "التسويق عن طريق تطبيقات التوصل الاجتماعي"
  },
  {
    "en": "Email Marketing",
    "ar": "التسويق من خلال البريد الإلكتروني"
  },
  {
    "en": "Per Voucher",
    "ar": "لكل قسيمه"
  },
  {
    "en": "Per Duration",
    "ar": "لكل فتره زمنيه"
  },
  {
    "en": "Advertisement Packages",
    "ar": "إعلانات التسويق"
  },
  {
    "en": "Featured Services",
    "ar": "الخدمات المميزه"
  },
  {
    "en": "What's New Section",
    "ar": "قسم ماهو جديد"
  },
  {
    "en": "Health Packages",
    "ar": "العروض المتعلقه بالصحه"
  },
  {
    "en": "REQUEST A QUOTATION",
    "ar": "طلب عرض سعر"
  },
  {
    "en": "No Internet Connection",
    "ar": "الإنترنت غير متوفر؟"
  },
  {
    "en": "Are you sure want to log out ?",
    "ar": "هلا تريد الخروج من التطبيق؟"
  },
  {
    "en": "Profile Updated Successfully",
    "ar": "تم تعديل حسابك بنجاح"
  },
  {
    "en": "Review & Ratings",
    "ar": "المراجعات والتقييمات"
  },
  {
    "en": "See All Reviews",
    "ar": "عرض جميع المراجعات"
  },
  {
    "en": "Replay on this Review",
    "ar": "جاوب علي هذه المراجعه"
  },
  {
    "en": "Write your replay here",
    "ar": "إكتب جوابك هنا"
  },
  {
    "en": "Please write your comment",
    "ar": "الرجاء كتابه التعليق"
  },
  {
    "en": "Are you sure you want to Exit?",
    "ar": "هلا تريد الخروج ؟"
  },
  {
    "en": "voucher package description",
    "ar": "تفاصيل القسيمه"
  },
  {
    "en": "health package description",
    "ar": "تفاصيل الحزم الصحيه"
  },
  {
    "en": "Whats New package description",
    "ar": "تفاصيل العروض الجديده"
  },
  {
    "en": "notification",
    "ar": "إشعار"
  },
  {
    "en": "email markting",
    "ar": "التسويق من خلال البريد الإلكتروني"
  }


]

// [
//   {
//     "en": "Sign Up Later",
//     "ar": "التسجيل لاحقا"
//   },
//   {
//     "en": "Beauty on fleek",
//     "ar": "الجمال المتكامل"
//   },
//   {
//     "en": "Don't have an Account?",
//     "ar": "لا يوجد لديك حساب"
//   },
//   {
//     "en": "Register Now",
//     "ar": "التسجيل الآن"
//   },
//   {
//     "en": "Need Help ?",
//     "ar": "تحتاج مساعده؟"
//   },
//   {
//     "en": "Forgot Password?",
//     "ar": "هل نسيت كلمه المرور؟"
//   },
//   {
//     "en": "User Name",
//     "ar": "إسم المستخدم"
//   },
//   {
//     "en": "Password",
//     "ar": "كلمه المرور"
//   },
//   {
//     "en": "LOGIN",
//     "ar": "الدخول"
//   },
//   {
//     "en": "Login via Facebook",
//     "ar": "الدخول عن طريق حساب  فيسبوك"
//   },
//   {
//     "en": "Login via Google",
//     "ar": "الدخول عن طريق حساب جوجل"
//   },
//   {
//     "en": "SIGN UP",
//     "ar": "التسجيل"
//   },
//   {
//     "en": "User",
//     "ar": "المستخدم"
//   },
//   {
//     "en": "SERVICE PROVIDER",
//     "ar": "مقدم الخدمه"
//   },
//   {
//     "en": "Upload Photo",
//     "ar": "تحميل صوره"
//   },
//   {
//     "en": "Confirm Password",
//     "ar": "تأكيد كلمه السر"
//   },
//   {
//     "en": "REGISTER",
//     "ar": "تسجيل"
//   },
//   {
//     "en": "By clicking \"REGISTER\" I agree to Terms & Conditions",
//     "ar": "عند الضغط على \"تسجيل\" أوافق على جميع الشروط."
//   },
//   {
//     "en": "Log In",
//     "ar": "دخول"
//   },
//   {
//     "en": "Your PIN",
//     "ar": "الرمز الخاص فيك"
//   },
//   {
//     "en": "Your Service",
//     "ar": "الخدمه الخاصه لك"
//   },
//   {
//     "en": "Settings",
//     "ar": "الإعدادات"
//   },
//   {
//     "en": "Health_Tourism",
//     "ar": "السياحه العلاجيه"
//   },
//   {
//     "en": "Currency",
//     "ar": "العمله"
//   },
//   {
//     "en": "Info",
//     "ar": "معلومات"
//   },
//   {
//     "en": "Contact",
//     "ar": "الشخص المعني"
//   },
//   {
//     "en": "Reviews & Ratings",
//     "ar": "مرجعات وتقييمات"
//   },
//   {
//     "en": "Dubai - JLT",
//     "ar": "دبي-أبراج بحيرات جميره"
//   },
//   {
//     "en": "Service Provider Default Name",
//     "ar": "إسم مقدم الخدمه"
//   },
//   {
//     "en": "View All >>",
//     "ar": "عرض الجميع"
//   },
//   {
//     "en": "PROCEED TO CHECK OUT",
//     "ar": "إتمام عمليه الشراء"
//   },
//   {
//     "en": "Types of Services",
//     "ar": "أنواع الخدمات"
//   },
//   {
//     "en": "Unlimited Vouchers",
//     "ar": "قسائم غير محدوده"
//   },
//   {
//     "en": "Social Media Marketing",
//     "ar": "التسويق من خلال تطبيقات التواصل الاجتماعي"
//   },
//   {
//     "en": "Email Marketing",
//     "ar": "التسويق من خلال البريد الإلكتروني"
//   },
//   {
//     "en": "Offer of the Month",
//     "ar": "عروض الشهر الحالي"
//   },
//   {
//     "en": "Whats New Section",
//     "ar": "قسم \"ماهو جديد\""
//   },
//   {
//     "en": "Would you like to Proceed",
//     "ar": "تريد أن تكمل"
//   },
//   {
//     "en": "A member of feeka will contact you shortly to finalize your Package",
//     "ar": "أحد موظفين فليكا سوف يتواصل معك "
//   },
//   {
//     "en": "Yes",
//     "ar": "نعم"
//   },
//   {
//     "en": "No",
//     "ar": "لا"
//   },
//   {
//     "en": "OK",
//     "ar": "أوافق"
//   },
//   {
//     "en": "Thank You!",
//     "ar": "شكرا لك"
//   },
//   {
//     "en": "EDIT",
//     "ar": "تحرير"
//   },
//   {
//     "en": "SAVE",
//     "ar": "حفظ"
//   },
//   {
//     "en": "Parking Access",
//     "ar": "مواقف"
//   },
//   {
//     "en": "Parking Minutes",
//     "ar": "عدد دقائق الإصطفاف"
//   },
//   {
//     "en": "Wheelchair Access",
//     "ar": "خدمات أهالي الهمم والإحتياجات الخاصه"
//   },
//   {
//     "en": "Wifi Access",
//     "ar": "خدمات إنترنت"
//   },
//   {
//     "en": "Opening Hours",
//     "ar": "ساعات العمل"
//   },
//   {
//     "en": "Something went wrong. Please try again later.",
//     "ar": "هناك خطأ يرجى المحاوله لاحقاً"
//   },
//   {
//     "en": "Top Ratings",
//     "ar": "أعلي التقييمات"
//   },
//   {
//     "en": "Old Password",
//     "ar": "كلمه المرور القديمه"
//   },
//   {
//     "en": "en",
//     "ar": "آنجليزي"
//   },
//   {
//     "en": "ar",
//     "ar": "عربي"
//   },
//   {
//     "en": "Top Deal",
//     "ar": "أفضل العروض"
//   },
//   {
//     "en": "What's New",
//     "ar": "ماهو جديد"
//   },
//   {
//     "en": "Select Service",
//     "ar": "آختيار خدمه"
//   },
//   {
//     "en": "Voucher Packages",
//     "ar": "قسائم"
//   },
//   {
//     "en": "Voucher Package",
//     "ar": "قسيمه"
//   },
//   {
//     "en": "Login",
//     "ar": "الدخول"
//   },
//   {
//     "en": "Main Screen",
//     "ar": "الشاشه الرئيسيه"
//   },
//   {
//     "en": "View More Screen",
//     "ar": "شاشه عرض المزيد"
//   },
//   {
//     "en": "Social Media Marketing",
//     "ar": "التسويق عن طريق تطبيقات التوصل الاجتماعي"
//   },
//   {
//     "en": "Email Marketing",
//     "ar": "التسويق من خلال البريد الإلكتروني"
//   },
//   {
//     "en": "Per Voucher",
//     "ar": "لكل قسيمه"
//   },
//   {
//     "en": "Per Duration",
//     "ar": "لكل فتره زمنيه"
//   },
//   {
//     "en": "Advertisement Packages",
//     "ar": "إعلانات التسويق"
//   },
//   {
//     "en": "Featured Services",
//     "ar": "الخدمات المميزه"
//   },
//   {
//     "en": "What\\'s New Section",
//     "ar": "قسم \"ماهو جديد\""
//   },
//   {
//     "en": "Health Packages",
//     "ar": "العروض المتعلقه بالصحه"
//   },
//   {
//     "en": "REQUEST A QUOTATION",
//     "ar": "طلب عرض سعر"
//   },
//   {
//     "en": "No Internet Connection",
//     "ar": "الإنترنت غير متوفر؟"
//   },
//   {
//     "en": "Are you sure want to log out ?",
//     "ar": "هلا تريد الخروج من التطبيق؟"
//   },
//   {
//     "en": "Profile Updated Successfully",
//     "ar": "تم تعديل حسابك بنجاح"
//   },
//   {
//     "en": "Review & Ratings",
//     "ar": "المراجعات والتقييمات"
//   },
//   {
//     "en": "See All Reviews",
//     "ar": "عرض جميع المراجعات"
//   },
//   {
//     "en": "Replay on this Review",
//     "ar": "جاوب علي هذه المراجعه"
//   },
//   {
//     "en": "Write your replay here",
//     "ar": "إكتب جوابك هنا"
//   },
//   {
//     "en": "Please write your comment",
//     "ar": "الرجاء كتابه التعليق"
//   },
//   {
//     "en": "Are you sure you want to Exit?",
//     "ar": "هلا تريد الخروج ؟"
//   },
//   {
//     "en": "voucher package description",
//     "ar": "تفاصيل القسيمه"
//   },
//   {
//     "en": "health package description",
//     "ar": "تفاصيل الحزم الصحيه"
//   },
//   {
//     "en": "Whats New package description",
//     "ar": "تفاصيل العروض الجديده"
//   },
//   {
//     "en": "notification",
//     "ar": "إشعار"
//   },
//   {
//     "en": "email markting",
//     "ar": "التسويق من خلال البريد الإلكتروني"
//   }
// ]