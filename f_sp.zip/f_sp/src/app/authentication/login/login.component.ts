import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
}
  from '@angular/forms';
import { AuthenticationService } from '../authentication.service';
import { CommonService } from '../../shared/common.service';
import { Router } from '@angular/router';
import { TranslateService } from '../../translate.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private service: CommonService,
    private translateService: TranslateService
  ) {
  }

  // language select function
  selectLanguage(str) {
    return this.service.selectLanguage(str);
  }

  // variable
  title = 'Fleeka';
  form: FormGroup;

  // functions

  ngOnInit() {
    if (!localStorage.getItem('_id')) {
      this.router.navigate(['auth/login']);
    }
    else {
      this.router.navigate(['main/dashboard']);
    }

    this.form = this.formBuilder.group({
      // email: ['', [Validators.required, Validators.email]],
      // password: [null, [Validators.required, Validators.maxLength(8)]]
      email: new FormControl('', Validators.compose([Validators.required, Validators.email])),
      password: ['', Validators.compose([Validators.required, Validators.minLength(6)])],

    });
  }

  login(form) {
    console.log('login function', form);
    if (form.status == 'VALID') {
      console.log('form is valid')

      let data = {
        "email": form.value.email,
        "password": form.value.password,
        "lang": localStorage.getItem('lang')
      }

      this.service.loginWith(data).subscribe(
        res => {
          console.log(res);
          if (res.status == 200) {
            var role = res.body._role.name
            var roleName = role.toLowerCase();

            // console.log("roleName::", roleName)
            if (roleName == "service provider") {
              this.router.navigate(['main/dashboard']);
            } else {
              let errorMsg = (localStorage.getItem('lang') == "ar") ? "معذرة! لا يحق لك الوصول إلى هذه اللوحة!!" : "Sorry ! you are not authorized to access this panel !!";
              this.service.success(errorMsg, 'Okay')
              localStorage.clear();
              localStorage.setItem('lang', 'en')
              this.router.navigate(['auth/login']);
            }
            // this.router.navigate(['main/dashboard']);
          } else {
            this.service.success(res.error.message, 'Okay')
          }
        },
        error => {
          console.log(error);
        });

    }
  }



}
