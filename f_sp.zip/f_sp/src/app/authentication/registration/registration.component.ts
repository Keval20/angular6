import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthenticationService } from '../authentication.service'
import { CommonService } from '../../shared/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { Location } from '@angular/common';

import { spThankyouDialog } from '../../dashboard/dialog/sp-reg-thankyou/sp-thankyou'
import { ConstantPool } from '@angular/compiler/src/constant_pool';
import { TranslateService } from '../../translate.service';

import { ReplaySubject } from 'rxjs';
import { MatSelect, VERSION } from '@angular/material';
import { Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { validateConfig } from '@angular/router/src/config';

interface Bank {
  id: string;
  name: string;
}


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit, OnDestroy {
  userFormData = {}
  FormData: FormData = new FormData();
  user: any;
  dataq: any;
  toastMessage: string;
  goto;

  countryCallingCode = [];


  public submitted: boolean = false;


  version = VERSION;

  /** control for the selected bank */
  public bankCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword */
  public bankFilterCtrl: FormControl = new FormControl();

  /** list of banks */
  private banks: Bank[] = [
    // { name: 'Bank A (Switzerland)', id: 'A' },
    // { name: 'Bank B (Switzerland)', id: 'B' },
    // { name: 'Bank C (France)', id: 'C' },
    // { name: 'Bank D (France)', id: 'D' },
    // { name: 'Bank E (France)', id: 'E' },
    // { name: 'Bank F (Italy)', id: 'F' },
    // { name: 'Bank G (Italy)', id: 'G' },
    // { name: 'Bank H (Italy)', id: 'H' },
    // { name: 'Bank I (Italy)', id: 'I' },
    // { name: 'Bank J (Italy)', id: 'J' },
    // { name: 'Bank Kolombia (United States of America)', id: 'K' },
    // { name: 'Bank L (Germany)', id: 'L' },
    // { name: 'Bank M (Germany)', id: 'M' },
    // { name: 'Bank N (Germany)', id: 'N' },
    // { name: 'Bank O (Germany)', id: 'O' },
    // { name: 'Bank P (Germany)', id: 'P' },
    // { name: 'Bank Q (Germany)', id: 'Q' },
    // { name: 'Bank R (Germany)', id: 'R' }
  ];

  /** list of banks filtered by search keyword */
  public filteredBanks: ReplaySubject<Bank[]> = new ReplaySubject<Bank[]>(1);

  @ViewChild('singleSelect') singleSelect: MatSelect;

  /** Subject that emits when the component has been destroyed. */
  private _onDestroy = new Subject<void>();



  constructor(
    private formBuilder: FormBuilder,
    private service: CommonService,
    public _location: Location,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private translateService: TranslateService

  ) {
    this.goto = this.service.goto;
    this.createForm();
    let str = this.translateService.getLanguage()
    this.translateService.selectLanguage(str);


  }

  @ViewChild('someModal') someModal: ElementRef;

  // variable
  title = 'Fleeka';
  form: FormGroup;
  image;
  fileToUpload: File;


  createForm() {
    this.form = this.formBuilder.group({
      name: ['', [Validators.required, Validators.maxLength(30)]],
      firstName: ['', [Validators.required, Validators.maxLength(30)]],
      // lastName: ['', [Validators.required]],
      phoneNumber: ['', Validators.compose([Validators.required, Validators.minLength(9), Validators.maxLength(16)])],
      email: new FormControl('', Validators.compose([Validators.required, Validators.email])),
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(15),
      ])],
      confirm_password: ['', Validators.required,],
      callingCode: ["", Validators.required]
    }, { validator: this.notmatchingPasswords('password', 'confirm_password') });
  }

  notmatchingPasswords(password, confirm_password) {
    return (group: FormGroup) => {
      if (group.controls[password].value === group.controls[confirm_password].value) {
        //  return { 'matchingPasswords': false }
      } else {
        return { 'matchingPasswords': true }
      }
    }
  }


  // functions
  ngOnInit() {
    // this.form = this.formBuilder.group({
    //   name: ['', [Validators.required, Validators.maxLength(30)]],
    //   firstName: ['', [Validators.required, Validators.maxLength(30)]],
    //   // lastName: ['', [Validators.required]],
    //   phoneNumber: ['', Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(16)])],
    //   email: new FormControl('', Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')])),
    //   // password: ['', Validators.compose([Validators.required, Validators.minLength(6)])],
    //   // confirmPassword: ['', Validators.compose([Validators.required, Validators.minLength(6)])],
    // });

    // this.countryCallingCode = this.route.snapshot.data.callinCodeDetails

    let getUAE = this.countryCallingCode.filter(code => code.name == "United Arab Emirates")
    console.log('getUAE', getUAE[0])
    

    console.log('reg countryCallingCode::', this.form.get('callingCode').value);

    // listen for search field value changes
    this.bankFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBanks();
      });

    //** Country calling code */
    if (Array.isArray(this.route.snapshot.data.callinCodeDetails)) {
      // this.route.snapshot.data.callinCodeDetails.map(ele => {
      //   let element = {
      //     "name": ele.name,
      //     "flag": ele.flag,
      //     "countryCode": ele.callingCodes[0],
      //   }
      //   this.countryCallingCode.push(element)

      // })
      for (var i = 0; i < this.route.snapshot.data.callinCodeDetails.length; i++) {
        let ele = this.route.snapshot.data.callinCodeDetails[i]
        let element = {
          "name": ele.name,
          "flag": ele.flag,
          "countryCode": ele.callingCodes[0],
        }
        this.countryCallingCode.push(element)
        if (element['name'].toLowerCase() == "united arab emirates") {
          // set defult as index of array
          let defult = this.countryCallingCode[i]
          this.form.get('callingCode').setValue(defult.countryCode);
          console.log('defult', defult)
        }
      }
    }

  }


  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  private filterBanks() {
    if (!this.countryCallingCode) {
      return;
    }
    // get the search keyword
    let search = this.bankFilterCtrl.value;
    if (!search) {

      this.filteredBanks.next(this.countryCallingCode.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBanks.next(
      this.countryCallingCode.filter(bank => bank.name.toLowerCase().indexOf(search) > -1)
    );
  }

  //****************************************************************** */
  goBack() {
    this._location.back();
  }

  /*Validation Number */
  only_number(event) {
    var k;
    k = event.charCode; // k = event.keyCode; (Both can be used)
    // console.log('key:' + k + "return : " + (k >= 48 && k <= 57))
    return ((k >= 48 && k <= 57));
  }

  registration(form) {
    console.log(form);
    if (form.status == 'VALID') {
      var formData: FormData = new FormData();

      var phone_number = "+" + form.value.callingCode + form.value.phoneNumber

      formData.append('name', form.value.name)
      formData.append('firstName', form.value.firstName)
      formData.append('email', form.value.email)
      formData.append('phoneNumber', phone_number)
      formData.append('password', form.value.password)
      formData.append('imageUrl', this.fileToUpload)
      formData.append('lang', localStorage.getItem('lang'))

      console.log("fromData::", formData)
      this.service.signupAdd('signup/service-provider', formData).subscribe(
        data => {
          if (data) {
            this.spthankyou();
            this.toastMessage = this.dataq.message;
            this.router.navigate(['auth/login']);
          }
        }
      )
    }
  }


  spthankyou() {
    // this.router.navigate(['main/dashboard/review-replay']);
    let dialogRef = this.dialog.open(spThankyouDialog, {
      width: '350px',
      data: { message: 'Are you sure you want to delete this record ? ' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {
        this.router.navigate(['auth/login']);
      }
      console.log('The dialog was closed', result);
    });
  }

  //** image show */
  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      this.fileToUpload = event.target.files && event.target.files[0];
      reader.readAsDataURL(event.target.files[0]); // read file as data url
      reader.onload = (event: any) => { // called once readAsDataURL is completed
        this.image = event.target.result

      }
    }
  }

}
