import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthenticationService } from '../authentication.service';
import { CommonService } from '../../shared/common.service';
import { TranslateService } from '../../translate.service';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    private Aservice: AuthenticationService,
    private service: CommonService,
    private router: Router,
    private route: ActivatedRoute,
    private translateService: TranslateService

  ) {

  }

  title = 'Fleeka';
  form: FormGroup;
  user: any;
  dataq: any;
  toastMessage: string;
  goto;


  ngOnInit() {
    this.form = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
    });
  }

  // forgetPassword(form) {
  //   console.log('forgot function', form);
  //   if (form.status == 'VALID') {
  //     console.log('form is valid')
  //     this.service.loginWith(form.value);

  //   }
  // }

  forgetPassword(form) {
    if (form.status == 'VALID') {
      let data = {
        "email": form.value.email,
        "lang": localStorage.getItem('lang')
      }
      console.log("form.value::", data)
      this.service.forgetPassword(data).subscribe(
        data => {
          if (data) {
            this.service.success(data.message, 'Okay')
            this.router.navigate(['auth/login']);
           
          }
        }
      )

    }

  }


}
