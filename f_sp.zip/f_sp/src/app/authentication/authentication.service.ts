import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { CommonService } from '../shared/common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(
    private http: HttpClient,
    private common: CommonService,
    private router: Router,
  ) { }


  /** Log a HeroService message with the MessageService */
  private log(message: string) {
    // this.messageService.add('HeroService: ' + message);
    console.log('message', message)
  }

  loginService(formData): Observable<any> {
    console.log('loginService function', formData);
    return this.http.post<any>(this.common.apiendpoint + 'signin', formData)
      .pipe(
        catchError(this.handleError('loginService', []))
      );
  }

  redirect() {
    this.router.navigate(['main/dashboard'])

  }

  loginWith(data) {
    return this.http.post(this.common.apiendpoint + 'signin', data).subscribe(
      data => { console.log(data) },
      err => console.error(err),
      () => {
        console.log('logout', data)
        this.router.navigate(['main/dashboard'])
      }
    )
  }

  logout(data: FormData) {
    return this.http.post(this.common.apiendpoint + 'signout', data).subscribe(
      data => { console.log(data) },
      err => console.error(err),
      () => {
        console.log('logout', data)
        this.router.navigate(['dashboard'])
      }
    )
  }



  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

}
