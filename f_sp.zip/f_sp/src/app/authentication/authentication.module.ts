// angular modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { TranslatePipe } from '../translate.pipe';
import { TranslateService } from '../translate.service';

// angular material modules

import {
  MatToolbarModule,
  MatButtonModule,
  MatSidenavModule,
  MatIconModule,
  MatListModule,
  MatGridListModule,
  MatCardModule,
  MatMenuModule,
  MatFormFieldModule,
  MatInputModule
} from '@angular/material';


// thrid   party


// custom compeonets and modules anfd services
import { AuthenticationRoutingModule } from './authentication-routing.module';
import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AuthenticationService } from './authentication.service';
import { CommonService } from '../shared/common.service';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RegistrationComponent } from './registration/registration.component';
import { MaterialModule } from '../shared/material/material.module';

import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

@NgModule({
  imports: [
    CommonModule,
    AuthenticationRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    HttpClientModule,
    MaterialModule,
    NgxMatSelectSearchModule

  ],

  declarations: [LoginComponent, ForgotPasswordComponent, RegistrationComponent],
  providers: [AuthenticationService]
})
export class AuthenticationModule { }
