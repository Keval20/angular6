import { PasswordMismatchDirective } from './password-mismatch.directive';

describe('PasswordMismatchDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordMismatchDirective();
    expect(directive).toBeTruthy();
  });
});
