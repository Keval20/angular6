import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@angular/cdk/layout';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuBarComponent } from './menu-bar/menu-bar.component';
import { HttpClientModule } from '@angular/common/http';
import { DialogOverviewExampleDialog } from './shared/dialog/dialog';

import { MaterialModule } from './shared/material/material.module';

//third party modules

import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { AgmCoreModule } from '@agm/core';

import { BarRatingModule } from "ngx-bar-rating";
import { NgHttpLoaderModule } from 'ng-http-loader'
import { DragScrollModule } from 'ngx-drag-scroll';

import { MatSpinner } from '@angular/material';
import { FlatTreeControl } from '@angular/cdk/tree';

import { infoDialog } from './dashboard/dialog/info/info';
import { contactDialog } from './dashboard/dialog/contact/contact';
import { thankyouDialog } from './dashboard/dialog/thankyou/thankyou';
import { packageInfoDialog } from './dashboard/dialog/package_info/package_info';
import { replyOnCommentDialog } from './dashboard/dialog/reply-on-comment/reply-on-comment';
import { spThankyouDialog } from './dashboard/dialog/sp-reg-thankyou/sp-thankyou';
import { servicesDialog } from './dashboard/dialog/services/services'
import { servicesInfoDialog } from './dashboard/dialog/services_info/services_info';
import { voucherActiveDialog } from './dashboard/dialog/vocher_active/voucher_active';
import { bannerImageDialog } from './dashboard/dialog/banner_image/banner_image';
import { DashboardModule } from './dashboard/dashboard.module';
import { CompareDirective } from './password-mismatch.directive';

import { voucherDescriptionDialog } from './dashboard/dialog/voucher_description/voucher_description';

import { AuthenticationModule } from './authentication/authentication.module';

// import { CustomerVoucherFormComponent } from './customer/voucher-form/voucher-form.component';
// import { ServiceDescriptioninfoDialog } from './dashboard/dialog/service-description/info';
@NgModule({
  declarations: [
    AppComponent,
    MenuBarComponent,
    DialogOverviewExampleDialog,
    infoDialog,
    contactDialog,
    thankyouDialog,
    replyOnCommentDialog,
    packageInfoDialog,
    spThankyouDialog,
    servicesDialog,
    servicesInfoDialog,
    voucherActiveDialog,
    bannerImageDialog,
    CompareDirective,
    voucherDescriptionDialog,
    // CustomerVoucherFormComponent,
    // ServiceDescriptioninfoDialog
    // TranslatePipe

  ],
  entryComponents: [
    MatSpinner,
    DialogOverviewExampleDialog,
    infoDialog,
    contactDialog,
    thankyouDialog,
    replyOnCommentDialog,
    packageInfoDialog,
    spThankyouDialog,
    servicesDialog,
    servicesInfoDialog,
    voucherActiveDialog,
    bannerImageDialog,
    voucherDescriptionDialog
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    HttpClientModule,
    MaterialModule,
    FormsModule,
    NgHttpLoaderModule,
    DragScrollModule,
    DashboardModule,
    NgxMaterialTimepickerModule.forRoot(),
    AgmCoreModule.forRoot({
      apiKey: "AIzaSyCdUusWtmoAiyEp9rTPQDwwpFY4Y1tHHcw",
      libraries: ["places"]
    }),
    ReactiveFormsModule,
    AuthenticationModule,

    // FormBuilder


  ],

  bootstrap: [AppComponent,]
})
export class AppModule { }
