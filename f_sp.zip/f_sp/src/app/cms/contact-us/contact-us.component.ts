import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { Component, ViewChild, OnInit } from '@angular/core';

import { Location } from '@angular/common';
import { TranslateService } from '../../translate.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  userFormData = {};
  dataq: any;
  toastMessage: string;
  result: any;
  fileToUpload: File;
  id: string;
  image = '';
  goto;
  dynamicHtml
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
    public _location: Location,
    private translateService: TranslateService,
  ) {

  }


  ngOnInit() {
  }


  goBack() {
    this._location.back();
  }
}
