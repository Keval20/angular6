import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CmsRoutingModule } from './cms-routing.module';
import { CmsListComponent } from './cms-list/cms-list.component';
import { MatTableModule, MatPaginatorModule, MatSortModule } from '@angular/material';
import { HowItWorksComponent } from './how-it-works/how-it-works.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FaqComponent } from './faq/faq.component';
import { MaterialModule } from '../shared/material/material.module';
import { FormsModule } from '@angular/forms';


@NgModule({
  imports: [
    CommonModule,
    CmsRoutingModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    // HttpClientModule,
    MaterialModule,
    FormsModule,
    
  ],
  declarations: [
    CmsListComponent, 
    HowItWorksComponent, 
    AboutUsComponent, 
    ContactUsComponent, 
    FaqComponent
  ]
})
export class CmsModule { }
