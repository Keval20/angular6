import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FaqComponent } from './faq/faq.component';
import { HowItWorksComponent } from './how-it-works/how-it-works.component';
import { CmsResolverDetails } from './cms.resolverDetails';

const routes: Routes = [
  {
    path : 'about-us',
    component: AboutUsComponent,
    resolve: {
      aboutus: CmsResolverDetails
    },
  },
  {
    path : 'contact-us',
    component: ContactUsComponent,
  },
  {
    path : 'faq',
    component: FaqComponent,
  },
  {
    path : 'how-it-works',
    component: HowItWorksComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    CmsResolverDetails
  ]
})
export class CmsRoutingModule { }
