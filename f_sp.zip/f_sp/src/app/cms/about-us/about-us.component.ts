import { ActivatedRoute, Router } from '@angular/router';
import { Component, ViewChild, OnInit } from '@angular/core';

import { Location } from '@angular/common';
import { CommonService } from '../../shared/common.service';
import { TranslateService } from '../../translate.service';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {

  userFormData = {};
  dataq: any;
  toastMessage: string;
  result: any;
  fileToUpload: File;
  id: string;
  image = '';
  goto;
  dynamicHtml
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service1: CommonService,
    public _location: Location,
    private translateService: TranslateService,
  ) {
    var data = {
      "identity": "ABOUTUS",
      // "language": "en"
      "language": this.service1.getlanguage()
    }
    this.service1.cmsCommon(data).subscribe(
      res => {
        this.dynamicHtml = res.content
        console.log(this.dynamicHtml);
      },
      error => {
        console.log(error);
      });
  }

  ngOnInit() {
    this.userFormData = this.route.snapshot.data.aboutus;
  }

  goBack() {
    this._location.back();
  }

  aboutUs() {

  }


}
