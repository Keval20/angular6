import { ActivatedRoute, Router } from '@angular/router';
import { Component, ViewChild, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { CommonService } from '../../shared/common.service';
import { TranslateService } from '../../translate.service';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
  dynamicHtml
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
    public _location: Location,
    private translateService: TranslateService,

  ) {

    var data = {
      "identity": "FAQS",
      // "language": "en"
      "language": this.service.getlanguage()
    }
    this.service.cmsCommon(data).subscribe(
      res => {
        this.dynamicHtml = res.content
        console.log(this.dynamicHtml);
      },
      error => {
        console.log(error);
      });


  }

  ngOnInit() {
  }

}
