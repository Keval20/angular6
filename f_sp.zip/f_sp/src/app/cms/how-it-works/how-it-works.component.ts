import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { Component, ViewChild, OnInit } from '@angular/core';

import { Location } from '@angular/common';
import { TranslateService } from '../../translate.service';

@Component({
  selector: 'app-how-it-works',
  templateUrl: './how-it-works.component.html',
  styleUrls: ['./how-it-works.component.css']
})
export class HowItWorksComponent implements OnInit {

  dynamicHtml
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
    private translateService: TranslateService,
  ) {

    var data = {
      "identity": "HIW_SP",
      // "language": "en"
      "language": this.service.getlanguage()
    }
    this.service.cmsCommon(data).subscribe(
      res => {
        this.dynamicHtml = res.content
        console.log(this.dynamicHtml);
      },
      error => {
        console.log(error);
      });


  }

  ngOnInit() {
  }

}
