import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MenuBarComponent } from './menu-bar/menu-bar.component';
import { DashboardResolverDetails } from './dashboard/dashboard.resolverDetails';
import { SettingsModule } from './settings/settings.module';
import { CmsModule } from './cms/cms.module';
import { MyaccountModule } from './myaccount/myaccount.module';
import { BannerImagesModule } from './banner-images/banner-images.module';
// import { ServiceProviderResolverDetails } from './service-provider/service-provider.resolverDetails';
import { VoucherModule } from './voucher/voucher.module';
import { SettingsMainResolverDetails } from './settings/settings_main.resolverDetails';
import { ServiceProviderResolverDetails } from './dashboard/service-provider.resolverDetails';

const routes: Routes = [

  {
    path: 'main',
    component: MenuBarComponent,
    resolve: {
      myplanq: ServiceProviderResolverDetails,
    },
    children: [
      {
        path: 'dashboard',
        loadChildren: './dashboard/dashboard.module#DashboardModule',
      },
      {
        path: 'my-account',
        loadChildren: './myaccount/myaccount.module#MyaccountModule'
      },
      {
        path: 'settings',
        loadChildren: './settings/settings.module#SettingsModule',
        resolve: {
          currencyDetails: SettingsMainResolverDetails,
        },
      },
      {
        path: 'cms',
        loadChildren: './cms/cms.module#CmsModule',
      },
      {
        path: 'voucher',
        loadChildren: './voucher/voucher.module#VoucherModule',
      },
      // {
      //   path: 'service-provider',
      //   loadChildren: './service-provider/service-provider.module#ServiceProviderModule',
      //   // canLoad:[AuthGuard]
      // },

    ]
  },
  {
    path: 'auth',
    loadChildren: './authentication/authentication.module#AuthenticationModule',
    // canLoad: [AuthGuard]
  },

  { path: '', redirectTo: '/auth', pathMatch: 'prefix' },
  { path: 'main/service-provider', redirectTo: 'main/dashboard', pathMatch: 'prefix' },
  { path: '**', redirectTo: 'auth/login', pathMatch: 'prefix' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: false })],
  exports: [RouterModule],
  providers: [DashboardResolverDetails, SettingsMainResolverDetails]
})

export class AppRoutingModule { }