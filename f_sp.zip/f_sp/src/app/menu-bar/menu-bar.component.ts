import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, Injectable, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { map } from 'rxjs/operators';
// import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { BehaviorSubject, Observable, of as observableOf } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../shared/common.service';
import { TranslateService } from '../translate.service';
import { Location } from '@angular/common';

@Component({
  selector: 'menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.css'],
  // providers: [FileDatabase],
})



export class MenuBarComponent {

  clinic_name: String;
  clinic_img: String;
  language: String;
  myplanAPI: any;
  // treeControl: FlatTreeControl<FileFlatNode>;
  // treeFlattener: MatTreeFlattener<FileNode, FileFlatNode>;
  // dataSource: MatTreeFlatDataSource<FileNode, FileFlatNode>;

  // hasChild = (_: number, _nodeData: FileFlatNode) => _nodeData.expandable;

  // transformer = (node: FileNode, level: number) => {
  //   return new FileFlatNode(!!node.children, node.filename, level, node.type);
  // }

  // private _getLevel = (node: FileFlatNode) => node.level;

  // private _isExpandable = (node: FileFlatNode) => node.expandable;

  // private _getChildren = (node: FileNode): Observable<FileNode[]> => observableOf(node.children);
  //  <a mat-list-item href="service-types">service-types</a>
  //   <a mat-list-item href="service-provider">Service Provider</a>
  //   <a mat-list-item href="package/service-package">Service Package</a>
  //   <a mat-list-item href="customer">Customer</a>
  //   <a mat-list-item href="package/voucher">Voucher</a>

  menuList = [
    { title: "Dashboard", titleAr: "لوحه القياده", url: "main/dashboard" },
    { title: "Voucher Status", titleAr: "حاله القسيمة", url: "main/voucher" },
    { title: "Package", titleAr: "حزمه", url: "main/dashboard/package" },
    { title: "How it works", titleAr: "كيف يعمل", url: "main/cms/how-it-works" },
    { title: "Settings", titleAr: "اعدادات", url: "main/settings" },
    { title: "About Us", titleAr: "من نحن", url: "main/cms/about-us" },
    { title: "FAQ's", titleAr: "اسئله وأجوبه", url: "main/cms/faq" },
    { title: "Contact Us", titleAr: "اتصل بنا", url: "main/cms/contact-us" },
    { title: "Profile", titleAr: "الشخصيه", url: "main/my-account/profile" },
    // { title: "Service Provider", url: "main/service-provider" },
    // { title: "Banner Images", url: "main/dashboard/banner-images" },
    // { title: "Logout", url: "main/logout" },
  ]

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
  activeIndex: number = 0;

  constructor(
    location: Location,
    private breakpointObserver: BreakpointObserver,
    private route: ActivatedRoute,
    private router: Router,
    public service: CommonService,
    private translateService: TranslateService,

  ) { }

  // language select function
  selectLanguage(str) {
    return this.translateService.selectLanguage(str);
  }

  /** For menu active show */
  redirectToPage(pagename, index) {
    console.log('index', index)
    this.activeIndex = index
    this.router.navigate([pagename.url])
  }

  ngOnInit() {
    let currentUrl = this.router.url;
    console.log("currentUrl::", currentUrl)
    this.clinic_img = this.service.getClinicImg();
    this.clinic_name = this.service.getClinicName();
    this.language = this.service.getlanguage();
  }
  // constructor(private breakpointObserver: BreakpointObserver, database: FileDatabase) {
  //   this.treeFlattener = new MatTreeFlattener(this.transformer, this._getLevel,
  //     this._isExpandable, this._getChildren);
  //   this.treeControl = new FlatTreeControl<FileFlatNode>(this._getLevel, this._isExpandable);
  //   this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  //   database.dataChange.subscribe(data => {
  //     this.dataSource.data = data;
  //   });
  // }

  logout() {
    this.service.logout().subscribe(
      data => {
        if (data) {
          localStorage.setItem('lang', (this.translateService.getLanguage()) ? this.translateService.getLanguage() : 'en')
          this.router.navigate(['auth/login'])
        }
      }
    )
  }

}
