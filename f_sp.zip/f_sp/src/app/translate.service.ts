import { Injectable } from '@angular/core';
import { TRANSLATIONS } from './translations'

@Injectable()
export class TranslateService {

  private currentLanguage = 'en';


  constructor() {

    var cart = localStorage.getItem('lang') || {};
    if (!cart) {
      localStorage.setItem('lang', this.currentLanguage);
    }
    // console.log('TranslateService')
    // localStorage.setItem('lang', this.currentLanguage);
    if (localStorage.length > 0) {
      // We have items
    } else {
      // No items
      localStorage.setItem('lang', this.currentLanguage);
    }

  }

  translate(str) {
    // return TRANSLATIONS.filter(entrada => entrada['en'] === str)[0][this.currentLanguage];
    let curlng = localStorage.getItem('lang');
    // console.log('translate chnage lan', curlng)
    return TRANSLATIONS.filter(entrada => entrada['en'] === str)[0][curlng];
  }

  selectLanguage(language) {
    //this.currentLanguage = language;
    //localStorage.setItem('lang', this.currentLanguage);

    localStorage.setItem('lang', language);
    // console.log('TranslateService selectLanguage', this.currentLanguage)
  }
  getLanguage() {
    // return this.currentLanguage
    return localStorage.getItem('lang');

  }

}
