import { Component, OnInit, ViewChild, NgZone, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { validateBasis } from '@angular/flex-layout';
import { ActivatedRoute, Router } from '@angular/router';
import { } from 'googlemaps';
import { MapsAPILoader } from '@agm/core';
import { MouseEvent } from '@agm/core';

import { MyaccountService } from '../myaccount.service';
import { CommonService } from '../../shared/common.service';




@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})



export class ProfileComponent implements OnInit {
  clinic_img: String;
  userFormData = {
    'address': {
      city: "",
      state: "",
      country: "",
    },
    imageUrl: ""
  }
  formData: FormData = new FormData();
  user: any;
  dataq: any;
  toastMessage: string;
  goto;
  id;
  addressDetails = {}
  responseData;
  letlong;

  componentForm = {
    'formatted_address': 'formatted_address',
    street_number: 'short_name',
    route: 'long_name',
    locality: 'long_name',
    administrative_area_level_1: 'long_name',
    country: 'long_name',
    postal_code: 'short_name'
  };
  image;
  fileToUpload: File;

  public latitude: number;
  public longitude: number;
  public searchControl: FormControl;
  public zoom: number;
  public latlong;

  @ViewChild("search")
  public searchElementRef: ElementRef;

  @ViewChild('myInput')
  myInputVariable: ElementRef;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    public service: CommonService,
    private router: Router,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
  ) {
    this.goto = this.service.goto

    this.id = localStorage.getItem('_id');

    if (!this.id) {
      this.router.navigate(['auth/login'])
    }

  }

  // vriables 

  title = 'Change Password';
  form: FormGroup;

  // functions

  // markers: marker = 
  //   {
  // 	  lat: 25.2171003,
  // 	  lng: 55.36136350000004,
  // 	  // label: 'A',
  // 	  draggable: true
  //   }

  markerDragEnd(eventLet: MouseEvent) {
    this.latlong = eventLet;
    this.latitude = this.latlong.coords.lat;
    this.longitude = this.latlong.coords.lng;
    console.log('dragEnd', eventLet);
  }

  //**  */

  goBack() {
    // this._location.back();
  }

  ngOnInit() {

    //set google maps defaults
    this.zoom = 4;
    this.latitude = 25.2171003;
    this.longitude = 55.36136350000004;

    //create search FormControl
    this.searchControl = new FormControl();

    //set current position
    // this.setCurrentPosition();

    //load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: []
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          //get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();

          //verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          //set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
          console.log('place.formatted_address', place.formatted_address)
          // Get each component of the address from the place details
          // and fill the corresponding field on the form.
          for (var i = 0; i < place.address_components.length; i++) {
            var addressType = place.address_components[i].types[0];
            if (this.componentForm[addressType]) {
              var val = place.address_components[i][this.componentForm[addressType]];
              this.addressDetails[addressType] = val;
            }
          }
          this.form.get('location').setValue(place.formatted_address),
            this.form.get('country').setValue(this.addressDetails["country"]),
            this.form.get('city').setValue(this.addressDetails["locality"]),
            this.form.get('state').setValue(this.addressDetails["administrative_area_level_1"]),
            this.form.get('zipCode').setValue(this.addressDetails["postal_code"])

        });
      });
    });




    this.form = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: [''],
      // phoneNumber: ['', Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])],
      phoneNumber: ['', Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(16)])],
      location: ['', Validators.required],
      country: ['', [Validators.required]],
      state: ['', Validators.required],
      city: ['', [Validators.required]],
      zipCode: ['', [Validators.required]],

    });

    this.userFormData = this.route.snapshot.data.getDetails;
    console.log('this.userFormData::', this.userFormData)
    this.clinic_img = this.service.getClinicImg();

    //set current position
    if (this.userFormData) {
      this.setCurrentPosition();
    }

    this.form.get('firstName').setValue(this.route.snapshot.data.getDetails.firstName);
    this.form.get('lastName').setValue(this.route.snapshot.data.getDetails.lastName);
    this.form.get('email').setValue(this.route.snapshot.data.getDetails.email);
    this.form.get('phoneNumber').setValue(this.route.snapshot.data.getDetails.phoneNumber);
    this.form.get('location').setValue(this.route.snapshot.data.getDetails.address.location);
    this.form.get('country').setValue(this.route.snapshot.data.getDetails.address.country);
    this.form.get('state').setValue(this.route.snapshot.data.getDetails.address.state);
    this.form.get('city').setValue(this.route.snapshot.data.getDetails.address.city);
    this.form.get('zipCode').setValue(this.route.snapshot.data.getDetails.address.zipCode);
    this.form.get('imageUrl').setValue(this.route.snapshot.data.getDetails.imageUrl);
    // this.form.setValue(this.route.snapshot.data.getDetails);

  }


  private setCurrentPosition() {
    this.latitude = +this.userFormData['address']['latitude'];
    this.longitude = +this.userFormData['address']['longitude'];
    this.zoom = 12;
  }


  // private setCurrentPosition() {
  //   if ("geolocation" in navigator) {
  //     navigator.geolocation.getCurrentPosition((position) => {
  //       this.latitude = position.coords.latitude;
  //       this.longitude = position.coords.longitude;
  //       this.zoom = 12;
  //     });
  //   }
  // }

  fetch() {
    console.log("this is fetch() function")
    this.id = localStorage.getItem('_id');
    if (!this.id) {
      this.router.navigate(['auth/login'])
    } else {
      var url = 'user/basic-details/' + this.id;
    }
    this.service.getDetails('user/basic-details/' + this.id).subscribe(
      data => {
        if (data) {
          this.responseData = data;
          this.service.clinic_img = this.service.filePath + this.responseData['imageUrl'];
          this.router.navigate(['main/dashboard'])
          console.log("getDetails() function call", this.service.clinic_img);
        }
      },
      err => console.error(err),

    )

  }

  myProfile(form) {
    console.log('myProfile', form);
    if (form.status == 'VALID') {

      if (this.id) {
        console.log('myProfile');
        var formData: FormData = new FormData();
        var addressData = {
          location: form.value.location,
          city: form.value.city,
          country: form.value.country,
          state: form.value.state,
          zipCode: (this.addressDetails["postal_code"]) ? this.addressDetails["postal_code"] : form.value.zipCode,
          latitude: this.latitude,
          longitude: this.longitude,
        }
        formData.append('firstName', form.value.firstName)
        formData.append('lastName', form.value.lastName)
        formData.append('phoneNumber', form.value.phoneNumber)
        formData.append('id', this.id)
        formData.append('address', JSON.stringify(addressData))
        formData.append('lang', localStorage.getItem('lang'))
        formData.append('imageUrl', this.fileToUpload)
        var url = 'service-provider/updateweb';
        this.service.update(url, formData).subscribe(
          data => {
            if (data) {
              console.log('profile')
              this.fetch();
              // this.router.navigate(['main/dashboard/profile']);
              this.service.success(data.message, 'Okay');
              this.service.clinic_img = this.service.filePath + this.responseData['imageUrl'];

            }
          },
          // this.service.update('user/basic-details', form.value).subscribe(
          // data => { this.dataq = data; },
          // err => { console.error(err); this.router.navigate(['error', '404']); },
          // () => {
          //   if (this.dataq.code == 200) {
          //     this.toastMessage = this.dataq.message;
          //     this.router.navigate(['main/dashboard']);
          //   } else {
          //     this.toastMessage = this.dataq.message;
          //   }
          // }
        )
      }
    }
  }




  //** Reset image shows */
  Reset(img) {
    console.log("img", img)
    this.image = "";
    // this.image.splice(index, 1);
    console.log(this.myInputVariable.nativeElement.files);
    this.myInputVariable.nativeElement.value = "";
    console.log(this.myInputVariable.nativeElement.files);
  }

  //** image show */
  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      this.fileToUpload = event.target.files && event.target.files[0];
      reader.readAsDataURL(event.target.files[0]); // read file as data url
      reader.onload = (event: any) => { // called once readAsDataURL is completed
        this.image = event.target.result

      }
    }
  }

  /*Validation Number */
  only_number(event) {
    var k;
    k = event.charCode;  //         k = event.keyCode;  (Both can be used)
    // console.log('key:' + k + "return : " + (k >= 48 && k <= 57))
    return ((k >= 48 && k <= 57));
  }


  //** Delete uploaded function */
  //   deleteImg(index) {
  //     // console.log("profile image delete function", index)

  //     if (!localStorage.getItem('_id')) {
  //         this.router.navigate(['auth/login']);
  //     }
  //     this.id = localStorage.getItem('_id')
  //     var data = {
  //         "serviceProviderId": this.id,
  //         "imageUrl": index
  //     }
  //     console.log("data", JSON.stringify(data))
  //     // console.log("data123::", data)
  //     var url = "admin/service-provider/image/delete"
  //     this.service.add(url, data).subscribe(
  //         data => {
  //             if (data) {
  //                 this.service.success(data.message, 'Okay')
  //             }
  //         }

  //     )

  // }

}

// just an interface for type safety.
interface marker {
  lat: number;
  lng: number;
  label?: string;
  draggable: boolean;
}