import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MyaccountService } from '../myaccount.service';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { Location } from '@angular/common';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})

export class ChangePasswordComponent implements OnInit {
  id: String;
  constructor(
    private formBuilder: FormBuilder,
    private service: CommonService,
    private route: ActivatedRoute,
    public _location: Location, ) {
    this.id = this.route.snapshot.params['id'];
  }

  // vriables 
  formData: FormData = new FormData();
  title = 'Change Password';
  form: FormGroup;
  pageTitle: string;
  user: any;
  userFormData: any = {}
  goto;

  // functions
  ngOnInit() {
    this.form = this.formBuilder.group({
      currentPassword: ['', Validators.compose([Validators.required, Validators.minLength(8)])],
      password: ['', Validators.compose([Validators.required, Validators.minLength(8)])],
    });

  }

  goBack() {
    this._location.back();
  }

  // goBack() {
  //   this._location.back();

  // }
  changePassword(form) {
    if (form.status == 'VALID') {
      this.service.changePassword(form.value).subscribe(
        data => { console.log(data) },
        err => { },
        () => {
        }

      )
    } else {
      console.log('else in invalid change password function');
    }
  }


}
