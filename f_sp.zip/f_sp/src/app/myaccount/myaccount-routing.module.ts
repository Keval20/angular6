import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { ProfileComponent } from './profile/profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { MyaccountResolverDetails } from './myaccount.resolverDetails';

const routes: Routes = [
  // {
  //   path: '',
  //   component: ProfileComponent,
  //   // canActivate: [AuthGuard],
  //   children: [
  //     {
  //       path: '',
  //       // canActivateChild: [AuthGuard],
  //       children: [
  //         { path: 'profile', component: ProfileComponent },
  //         { path: 'change-password', component: ChangePasswordComponent }
  //       ]
  //     }
  //   ]
  // }
 
  {
    path: 'profile',
    component: ProfileComponent,
    resolve: {
      getDetails: MyaccountResolverDetails
    }
  },
  {
    path: 'change-password',
    component: ChangePasswordComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [MyaccountResolverDetails]
})
export class MyaccountRoutingModule { }
