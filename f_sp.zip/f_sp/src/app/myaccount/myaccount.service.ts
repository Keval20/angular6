import { Injectable } from '@angular/core';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { CommonService } from '../shared/common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class MyaccountService {

  constructor(
     private common: CommonService,
     private router: Router
  ) { }

  private log(message: string) {
    // this.messageService.add('HeroService: ' + message);
    console.log('message', message);
  }
  
  // redirect() {
  //   this.router.navigate(['main/dashboard'])

  // }

}
