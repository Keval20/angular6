
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { MyaccountService } from './myaccount.service';
import { catchError, map, tap, delay } from 'rxjs/operators';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CommonService } from '../shared/common.service';

@Injectable()

// newly added by vighnesh
export class MyaccountResolverDetails implements Resolve<any> {
    user: string;

    id;

    formData: FormData = new FormData();
    constructor(
        private router: Router,
        private service: CommonService) { }
    resolve(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<any> {
        // const id = route.paramMap.get('id');
        // this.id = "5b33853dfe93232d50c050d3";
        this.id = localStorage.getItem('_id');
        if (!this.id) {
            this.router.navigate(['auth/login'])
        } else {
            var url = 'user/basic-details/' + this.id;
        }

        return this.service.getDetails(url)

    }
}