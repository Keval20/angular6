// angular module
import { NgModule, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AgmCoreModule } from '@agm/core';

// angular matiral modules
import { MaterialModule } from '../shared/material/material.module';


// third party


// custome  components and module and services
import { MyaccountRoutingModule } from './myaccount-routing.module';
import { ProfileComponent } from './profile/profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    MyaccountRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    AgmCoreModule.forRoot({
      apiKey: "AIzaSyCdUusWtmoAiyEp9rTPQDwwpFY4Y1tHHcw",
      libraries: ["places"]
    })
  ],
  declarations: [ProfileComponent, ChangePasswordComponent]
})

export class MyaccountModule { }
