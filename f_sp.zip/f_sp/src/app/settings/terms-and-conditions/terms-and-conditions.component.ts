import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { Component, ViewChild, OnInit } from '@angular/core';

@Component({
  selector: 'app-terms-and-conditions',
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions.component.css']
})
export class TermsAndConditionsComponent implements OnInit {

 
  dynamicHtml
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,

  ) {

    var data = {
      "identity": "TC",
      // "language": "en"
      "language": this.service.getlanguage()
    }
    this.service.cmsCommon(data).subscribe(
      res => {
        this.dynamicHtml = res.content
        console.log(this.dynamicHtml);
      },
      error => {
        console.log(error);
      });


  }

  ngOnInit() {
  }

}
