import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// import { ChangePasswordComponent } from './change-password/change-password.component';
// import { ChangeUsernameComponent } from './change-username/change-username.component';
// import { CurrencyComponent } from './currency/currency.component';
// import { LanguageComponent } from './language/language.component';
// import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
// import { PushNotificationComponent } from './push-notification/push-notification.component';
// import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { SettingsMainComponent } from './settings-main/settings-main.component';
import { SettingsMainResolverDetails } from './settings_main.resolverDetails';
import { MyaccountResolverDetails } from '../myaccount/myaccount.resolverDetails';

const routes: Routes = [
  // {
  //   path:'push-notification',
  //   component: PushNotificationComponent
  // },
  // {
  //   path:'change-username',
  //   component: ChangeUsernameComponent
  // },
  // {
  //   path:'change-password',
  //   component: ChangePasswordComponent
  // },
  // {
  //   path:'language',
  //   component: LanguageComponent
  // },
  // {
  //   path:'currency',
  //   component: CurrencyComponent
  // },
  // {
  //   path:'privacy-policy',
  //   component: PrivacyPolicyComponent
  // },
  // {
  //   path:'terms-and-condition',
  //   component: TermsAndConditionsComponent
  // },  
  {
    path: '',
    component: SettingsMainComponent,
    resolve: {
      getDetails: MyaccountResolverDetails,
    },

  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    SettingsMainResolverDetails, MyaccountResolverDetails
  ]
})
export class SettingsRoutingModule { }
