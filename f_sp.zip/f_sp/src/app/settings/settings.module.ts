import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/material/material.module';
import { SettingsRoutingModule } from './settings-routing.module';
// import { ChangePasswordComponent } from './change-password/change-password.component';
// import { LanguageComponent } from './language/language.component';
// import { CurrencyComponent } from './currency/currency.component';
// import { PushNotificationComponent } from './push-notification/push-notification.component';
// import { ChangeUsernameComponent } from './change-username/change-username.component';

import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { FormsModule, FormBuilder, ReactiveFormsModule  } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SettingsMainComponent } from './settings-main/settings-main.component';

@NgModule({
  imports: [
    CommonModule,
   
    // HttpClientModule,
    MaterialModule,
    FormsModule,
    // FormBuilder,
    SettingsRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [
    // ChangePasswordComponent, 
    // LanguageComponent, 
    // CurrencyComponent, 
    // PushNotificationComponent, 
    // ChangeUsernameComponent, 
    PrivacyPolicyComponent, 
    TermsAndConditionsComponent, 
    SettingsMainComponent
  ]
})
export class SettingsModule { }
