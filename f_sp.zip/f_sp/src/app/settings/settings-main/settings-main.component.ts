import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../../shared/common.service';
import { Component, ViewChild, OnInit } from '@angular/core';

import { Location } from '@angular/common';
// import { FormGroup } from '@angular/forms';

import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { DialogOverviewExampleDialog } from '../../shared/dialog/dialog';
import { TranslateService } from '../../translate.service';


function passwordConfirming(c: AbstractControl): any {
  if (!c.parent || !c) return;
  const pwd = c.parent.get('password');
  const cpwd = c.parent.get('confirmPassword')

  if (!pwd || !cpwd) return;
  if (pwd.value !== cpwd.value) {
    return { invalid: true };

  }
}

@Component({
  selector: 'app-settings-main',
  templateUrl: './settings-main.component.html',
  styleUrls: ['./settings-main.component.css']
})
export class SettingsMainComponent implements OnInit {
  language: String;
  currencyData;
  dataq: any;
  toastMessage: string;
  result: any;
  fileToUpload: File;
  id: string;
  image = '';
  goto;
  action;

  hide = true;
  hide1 = true;
  hide2 = true;
  hidee = true;
  form: FormGroup;
  userFormData = {
    "lang": "",
    "activationPin": "",
  };


  get cpwd() {
    return this.form.get('confirmPassword');
  }



  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
    public _location: Location,
    public dialog: MatDialog,
    private formBuilder: FormBuilder,
    private translateService: TranslateService
  ) {
    this.id = this.route.snapshot.params['id'];
    this.goto = this.service.goto;

    this.id = localStorage.getItem('_id');

    if (!this.id) {
      this.router.navigate(['auth/login'])
    }

    this.createForm();

  }
  createForm() {
    this.form = this.formBuilder.group({
      currentPassword: ['', Validators.required],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(15),
      ])],
      confirm_password: ['', Validators.required,]
    }, { validator: this.notmatchingPasswords('password', 'confirm_password') });
  }

  notmatchingPasswords(password, confirm_password) {
    return (group: FormGroup) => {
      if (group.controls[password].value === group.controls[confirm_password].value) {
        //  return { 'matchingPasswords': false }
      } else {
        return { 'matchingPasswords': true }
      }
    }
  }
  // variable
  title = 'Change Password';

  ngOnInit() {
    this.language = this.service.getlanguage();
    // console.log("settings screen language::", this.language)
    this.userFormData = this.route.snapshot.data.getDetails;
    this.userFormData['lang'] = localStorage.getItem('lang');
    console.log('this.userFormData::', this.userFormData)

    this.currencyData = this.route.snapshot.data.currencyDetails;
    // console.log("this.currencyData::", this.currencyData)
  }

  //** Change Password */
  changePassword(form) {
    if (form.status == 'VALID') {
      let pass = {
        currentPassword: form.value.currentPassword,
        password: form.value.password,
        confirm_password: form.value.confirm_password,
        lang: localStorage.getItem('lang')
      }
      // console.log("pass::", pass);
      this.service.add('user/change-password-new', pass).subscribe(
        data => {
          if (data) {
            this.service.success(data.message, "Okay")
            localStorage.clear()
            localStorage.setItem('lang', 'en')
            this.router.navigate(['auth/login']);
          }
        }
      )
    } else {
      console.log('else in invalid change password function');
    }

  }

  //** change language */
  changeLanguage(form) {

    if (form.status == 'VALID') {
      this.service.changeLangugage(form.value).subscribe(
        data => {
          if (data) {
            var lang = form.value.lang;
            console.log('fleeka123', lang)
            localStorage.setItem('lang', lang);
            this.service.success(data.message, "Okay")
            this.router.navigate(['main/dashboard'])
          }
        },
      )
    } else {
      console.log('else in invalid change language function');
    }

  }

  //** change Currency */
  changeCurrency(form) {

    if (form.status == 'VALID') {
      console.log("form.value::", form.value)
      this.service.changeCurrency(form.value).subscribe(
        data => {
          if (data) {
            this.service.success(data.message, 'Okay')
          }
        }
      )
    } else {
      console.log('else in invalid change language function');
    }

  }

  //** change Activation pin function */
  updateActivationPin(form) {

    if (form.status == 'VALID') {
      // console.log("form.value::", form.value)
      this.service.changeactivationPin(form.value).subscribe(
        data => {
          if (data) {
            this.service.success(data.message, 'Okay')
          }
        }
      )
    } else {
      console.log('else in invalid change activation pin');
    }

  }

  //** deactive account function */
  deactiveAccount(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '300px',
      data: { message: 'Are you sure you want to ' + this.service.activeToolTipe + ' ? ' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {
        if (this.id) {
          this.service.deactivateAccount().subscribe(
            data => {
              if (data) {
                localStorage.setItem('lang', 'en');
                this.router.navigate(['auth/login'])
                this.service.success(data.message, 'Okay')
              }
            }
          )
        } else {
          console.log("else error in dectivate account");
        }
      }
    });
  }

  only_number(event) {
    var k;
    k = event.charCode;  //         k = event.keyCode;  (Both can be used)
    // console.log('key:' + k + "return : " + (k >= 48 && k <= 57))
    return ((k >= 48 && k <= 57));
  }

}
