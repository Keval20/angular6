import { Component, OnInit, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


import { CommonService } from '../../shared/common.service';
import { voucherActiveDialog } from '../../dashboard/dialog/vocher_active/voucher_active';
import { TranslateService } from '../../translate.service';
import { voucherDescriptionDialog } from '../../dashboard/dialog/voucher_description/voucher_description';

@Component({
  selector: 'app-voucher',
  templateUrl: './voucher.component.html',
  styleUrls: ['./voucher.component.css']
})
export class VoucherComponent implements OnInit {
  language: String;
  vouchersData = [];

  Active = [];
  Reserved = [];
  Used = [];
  Expired = [];
  toastMessage: String;
  id;
  dataq;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonService,
    private _location: Location,
    public dialog: MatDialog,
    private translateService: TranslateService,
  ) { }

  ngOnInit() {

    this.language = this.service.getlanguage();

    this.vouchersData = this.route.snapshot.data.voucherDetails
    if (Array.isArray(this.vouchersData)) {
      this.vouchersData.forEach(element => {
        if (element.status == 'Used') {
          this.Used.push(element)
        } else if (element.status == 'Reserved') {
          this.Reserved.push(element)
        } else if (element.status == 'Expired') {
          this.Expired.push(element)
        } else {
          this.Active.push(element)
        }

      });
    } else {
      this.vouchersData = []
    }
    console.log("this.vouchersData", JSON.stringify(this.vouchersData))
  }


  goBack() {
    this._location.back();
  }

  //** avctive voucher open dialog box */
  activateVoucher(voucherData) {
    console.log("voucherData::", voucherData);

    let dialogRef = this.dialog.open(voucherActiveDialog, {
      // height: '400px',
      width: '400px',
      data: { message: 'Are you sure you want to delete this record ? ', data: voucherData }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {

      }
      console.log('The dialog was closed', result);
    });
  }


  //** avctive voucher function */
  // activateVoucher1(data) {
  //   var _id = data._id
  //   var _serviceProvider = data._serviceProvider
  //   console.log("_id", _id);


  //   if (!localStorage.getItem('_id')) {
  //     this.router.navigate(['auth/login']);
  //   }
  //   this.id = localStorage.getItem('_id')

  //   var voucherData = {
  //     "vocher": _id,
  //     "_serviceProvider": _serviceProvider,
  //     "activationPin": ""
  //   }
  //   console.log("voucherData::", voucherData);

  //   var url = 'user/avail-voucher'
  //   this.service.update(url, voucherData).subscribe(
  //     data => { this.dataq = data },
  //     err => { console.error('error found', err); this.router.navigate(['error', '404']); },
  //     () => {

  //     }
  //   )

  // }

  ratings(voucher) {
    console.log("voucherData::", voucher)
    this.service.userIdForVoucher = voucher.user_id
    this.router.navigate(['main/dashboard/reviews']);
  }

  packageInfo(voucherDetails) {
    console.log("voucherDescription::", voucherDetails)
    let dialogRef = this.dialog.open(voucherDescriptionDialog, {
      width: '450px',
      data: { message: 'Are you sure you want to delete this record ? ', data: voucherDetails }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('The dialog was closed', result);
        // this.saveModelData('packageInfo', result)
      }

    });

  }


}
