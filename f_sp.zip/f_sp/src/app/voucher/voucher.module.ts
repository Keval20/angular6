import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/material/material.module';


import { VoucherRoutingModule } from './voucher-routing.module';
import { VoucherComponent } from './voucher/voucher.component';

@NgModule({
  imports: [
    CommonModule,
    VoucherRoutingModule,
    MaterialModule
  ],
  declarations: [VoucherComponent]
})
export class VoucherModule { }
