import { BannerImagesModule } from './banner-images.module';

describe('BannerImagesModule', () => {
  let bannerImagesModule: BannerImagesModule;

  beforeEach(() => {
    bannerImagesModule = new BannerImagesModule();
  });

  it('should create an instance', () => {
    expect(bannerImagesModule).toBeTruthy();
  });
});
