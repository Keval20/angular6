import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-images',
  templateUrl: './banner-images.component.html',
  styleUrls: ['./banner-images.component.css']
})
export class BannerImagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  cons
}
