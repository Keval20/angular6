import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';

import { BannerImagesRoutingModule } from './banner-images-routing.module';
import { BannerImagesComponent } from './banner-images/banner-images.component';
import { MaterialModule } from '../shared/material/material.module';




@NgModule({
  imports: [
    CommonModule,
    BannerImagesRoutingModule,
    MaterialModule,
    FormsModule
  ],
  declarations: [BannerImagesComponent]
})
export class BannerImagesModule { }
